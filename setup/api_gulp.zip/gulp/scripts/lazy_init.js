(function(w, d){
	var b = d.getElementsByTagName('body')[0];
	var s = d.createElement("script"); s.async = true;
	s.src = "https://cdn.jsdelivr.net/npm/vanilla-lazyload@12.4.0/dist/lazyload.min.js";

	w.lazyLoadOptions = {
		elements_selector: ".lazy"
	}; // Your options here. See "recipes" for more information about async. https://github.com/verlok/lazyload

	b.appendChild(s);

	if(!("IntersectionObserver" in w)){ //IE
		var s = d.createElement("script"); s.async = true;
		s.src = "https://cdn.jsdelivr.net/npm/intersection-observer@0.7.0/intersection-observer.js";
		b.appendChild(s);
	}

}(window, document));