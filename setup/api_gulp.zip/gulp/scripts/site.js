/**
 * Limit numeric inputs
 *
 * Accepts: 0-9, ".", ",", backspace, arrow keys, tab, and delete
 * 
 */
jQuery('body').on('keydown', '.number-input', function(e){
	//console.log('Number input testing: '+e.which);

	if (!((e.which >= 48 && e.which <= 57) || (e.which >= 96 && e.which <= 105) || e.which == 110 || (e.which == 173 || e.which == 109) || e.which == 188 || e.which == 190 || e.which == 8 || e.which == 9 || e.which == 37 || e.which == 39 || e.which == 46 )) {
		return false;
	}

});

//RESIZE ACTIONS
//When you need to take action on resize. Uses debounce functionality
//leave commented out unless needed.
/*
var resizeTimer = null;

$(window).on('resize', function(e) {

  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function() {

  }, 100);

});
*/

/**
 * GRAVITY FORMS
 *
 * Gravity forms need's a little love to work how we want. Put that code here
 */
//Default functionality for file upload form fields
jQuery(document).bind('gform_post_render', function(){
	jQuery(".gfield.file input[type='file']").on('change', function() {
		var filename = jQuery(this).val().replace("C:\\fakepath\\", "");
		jQuery(this).parent().parent().find('label').attr('data-content',filename);
	});

	//Setup some JS validation for the gravity forms. Specifically targeting billing values.
	jQuery('.address_zip input').addClass('number-input').attr('maxlength', 5);
	jQuery('.ginput_container_creditcard .ginput_full').first().find('input').addClass('number-input').attr('maxlength', 19);
	jQuery('.ginput_cardinfo_right input').addClass('number-input').attr('maxlength', 4);

});


//check to make sure we actually have a gform, otherwise we can just avoid this code.
if(jQuery('.gform_wrapper form').length){

	var $form = jQuery('.gform_wrapper form');

	//disable the submit button when the form is submitted
	$form.submit(function(e){
		jQuery('.gform_footer button').prop('disabled', true);
	});

}

var userLocation = pkGetCookie('userLocation');

if(! userLocation){
	$.getJSON('http://www.geoplugin.net/json.gp?jsoncallback=?', function(data) {
		if(data && data.geoplugin_city){
			pkSetCookie('userLocation', JSON.stringify(data), 1);
		}
	});
}else{
	userLocation = JSON.parse(userLocation);
}


