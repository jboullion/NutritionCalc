<?php
/**
 * Get the nearest events based on city and state of the user
 */
require_once('event-setup.php');

if(empty($_POST['city']) || empty($_POST['state'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$count = ! empty($_POST['count']) && is_numeric($_POST['count'])?$_POST['count']:4;
$radius = ! empty($_POST['radius']) && is_numeric($_POST['radius'])?$_POST['radius']:0;

$Event = new Event(0, $wpdb);

$latest_events = $Event->get_nearest_events($_POST['city'], $_POST['state'], $radius, $count);

if(! empty($latest_events)){
	echo json_encode($latest_events);
}else{
	echo json_encode(array('error'=> 'Unable to get event information'));
}

exit();
