
<?php 
/**
 * This Class will be used as the model for our Users information
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is a user table diagram for reference
 */

require_once('Base.php');

class User extends Base {
	protected $_user_id = 0;

	protected $location_table = 'user_location';
	protected $activity_table = 'user_activity';

	public function __construct($user_id, $wpdb, $debug = false){
		parent::__construct($wpdb, $debug);

		$this->_user_id = $user_id;
	}

	/**
	 * Get this users basic information
	 * 
	 * @return Object The object model of this user
	 */
	public function get_info(){
		return $this->info;
	}

	/**
	 * Update this users information
	 * 
	 * TODO: Need to update this function to work with multiple tables for different data
	 * 
	 * @param int $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 */
	public function update_info($info, $user_table){

		$info = $this->clean_info($info, array('user_id'));

		$result = $this->_wpdb->update(
			$this->_wpdb->prefix.$user_table,
			(array)$info, //by default out info is in Object form. So let's convert that to an array for updating
			array(
				'user_id' => $this->_user_id
			)
		);

		return $result;
	}


}