
<?php 
/**
 * This Class will be used as the model for our item information
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is a item table diagram for reference
 */

require_once('Base.php');

class MarketItem extends Base {
	protected $_item_id = 0;
	protected $images = [];
	
	protected $item_table = 'market_item';
	protected $types_table = 'market_type';
	protected $subtypes_table = 'market_subtype';
	protected $listing_type_table = 'market_listing_type';

	// NOTE: The images table is a many to one relationship with the items table. Becareful not to accidentially pull in too many results when joining this table
	protected $image_table = 'market_images';

	// We need to limit the columns we get from the picture table to prevent overwriting other columns (specifically item_id)
	protected $image_columns = 'I.*, T.*, UL.*, P.img_title, P.url, P.width, P.height';

	protected $member_table = 'member';

	/**
	 * Build our item
	 */
	public function __construct($item_id, $wpdb, $debug = false){
		parent::__construct($wpdb, $debug);
		$this->_item_id = $item_id;
	}


	/**
	 * Get this items basic information
	 * 
	 * @param int $item_id The ID of the item making the query
	 */
	public function get_info($item_id = 0){

		if(empty($item_id)){
			$item_id = $this->_item_id;
		}

		// $this->pk_print('item_id: '.$item_id);

		$this->info = $this->_wpdb->get_row($this->_wpdb->prepare("SELECT I.*, T.*, M.*, UL.*, UI.thumbnail_url as user_img
																	FROM {$this->_wpdb->prefix}{$this->item_table} AS I
																	LEFT JOIN {$this->_wpdb->prefix}{$this->types_table} AS T USING(`type_id`)
																	LEFT JOIN {$this->_wpdb->prefix}{$this->member_table} AS M USING(`user_id`)
																	LEFT JOIN {$this->_wpdb->prefix}{$this->user_location} AS UL USING(`user_id`)
																	LEFT JOIN {$this->_wpdb->prefix}{$this->user_images} AS UI USING(`user_id`)
																	WHERE I.`item_id` = %d", $item_id));

																	// LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P USING(item_id)

		// $this->print_wpdb_errors();

		return $this->info;
	}


	/**
	 * Get this items basic information
	 * 
	 * @param int $item_id The ID of the item making the query
	 */
	public function get_related_items($search_args = array()){
		if(empty($search_args['item_id'])){
			$item_id = $this->_item_id;
		}else{
			$item_id = $search_args['item_id'];
		}

		// Get our source item
		$source_item = $this->get_info($item_id);

		// Search for items similar to this item, ignore this item though
		$search_query = $this->_wpdb->prepare("SELECT item_id 
												FROM {$this->_wpdb->prefix}{$this->item_table} AS I 
												WHERE (`subtype_id` = %d OR `type_id` = %d ) 
													AND item_id != %d", 
													$source_item->subtype_id, 
													$source_item->type_id, 
													$item_id);
												
												// Removed the "listing" check, but may want to add it back
												// OR `listing_id` = %d
												// $source_item->listing_id,

		// ALL matches found with this query
		$matches = $this->_wpdb->get_results($search_query);

		// $this->print_wpdb_errors();

		$max = count($matches);

		$offset = empty($search_args['offset'])?0:$search_args['offset'];
		$count = empty($search_args['count'])?12:$search_args['count'];
		
		// The matches being returned based on an offset of the total results
		// We are also ATTEMPTING to order by "relevance" in that we want the items that match the subtype AND the type to be listed first and then other things afterwards
		$related = $this->_wpdb->get_results(
				$this->_wpdb->prepare("SELECT {$this->image_columns} FROM {$this->_wpdb->prefix}{$this->item_table} AS I
										LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P ON P.item_id = I.item_id AND P.featured = 1
										LEFT JOIN {$this->_wpdb->prefix}{$this->types_table} AS T USING(`type_id`)
										LEFT JOIN {$this->_wpdb->prefix}{$this->user_location} AS UL USING(`user_id`)
										WHERE I.item_id IN ({$search_query})
										ORDER BY 
											CASE WHEN subtype_id = {$source_item->subtype_id} AND `type_id` = {$source_item->type_id} THEN 0
												WHEN subtype_id = {$source_item->subtype_id} OR `type_id` = {$source_item->type_id} THEN 1
												ELSE 3
											END
										LIMIT %d, %d", $offset, $count)
				);

		//views DESC

		// $this->print_wpdb_errors();

		return array('items' => $related, 'max' => $max);
	}

	

	/**
	 * Get this items images information
	 * 
	 * @param int $item_id The ID of the item making the query
	 */
	public function get_images(){
		$this->images = $this->_wpdb->get_results($this->_wpdb->prepare("SELECT * FROM {$this->_wpdb->prefix}{$this->image_table} AS P
																	WHERE `item_id` = %d", $this->_item_id));

		return $this->images;
	}


	/**
	 * Update this items information
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return bool The result of the update query. === false means fail but === 0 means no rows updated
	 */
	public function update_info($info){

		$info = $this->clean_info($info, array('item_id'));

		$result = $this->_wpdb->update(
			$this->_wpdb->prefix.$this->item_table,
			(array)$info, //by default out info is in Object form. So let's convert that to an array for updating
			array(
				'item_id' => $this->_item_id
			)
		);

		if($result === false && $this->_debug){
			// Error occured
			die('update error: '+$this->_wpdb->last_error);
		}else{
			return $result;
		}
	}


	/**
	 * Create a new item
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return int The ID of the item that was just created
	 */
	public function create_item($info){

		$info = $this->clean_info($info, array('item_id'));

		$result = $this->_wpdb->insert(
			$this->_wpdb->prefix.$this->item_table,
			(array)$info //by default out info is in Object form. So let's convert that to an array for updating
		);

		if($result === false && $this->_debug){
			// Error occured
			die('create error: '+$this->_wpdb->last_error);
		}else{
			return $this->_wpdb->insert_id;
		}

	}


	/**
	 * Get the last X items from the items database. Ordered by creation date.
	 * 
	 * @param int $count The number of items to get from the DB
	 * 
	 * @return array A list of the most recent items from the Marketplace
	 */
	public function get_latest_items($count = 9){
		$result = $this->_wpdb->get_results(
				$this->_wpdb->prepare("SELECT {$this->image_columns} FROM {$this->_wpdb->prefix}{$this->item_table} AS I
										LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P ON P.item_id = I.item_id AND P.featured = 1
										LEFT JOIN {$this->_wpdb->prefix}{$this->types_table} AS T USING(`type_id`)
										LEFT JOIN {$this->_wpdb->prefix}{$this->user_location} AS UL USING(`user_id`)
										ORDER BY created DESC
										LIMIT %d", $count)
				);

		return $result;
	}


	/**
	 * Search for items and return them in an array
	 * 
	 * @param int $offset The offset of items to load
	 * @param array $search_args The columns and values to search by
	 * @param int $count The number of items to get from the DB
	 * 
	 * @return array A list of matching items from the Marketplace
	 */
	public function search_items($search_args = array()){

		// If we are passing in a city and state the let's do a radius search
		if(! empty($search_args['city']) && ! empty($search_args['state']) ){
			$location = $this->get_cached_location($search_args['city'], $search_args['state']);
			$user_sql = $this->get_users_by_radius_sql($location, $search_args['radius']);

			$search_query = "SELECT item_id FROM {$this->_wpdb->prefix}{$this->item_table} AS I WHERE I.`user_id` IN ({$user_sql}) ";
		}else{
			// If no city or state just ignore user / item location
			$search_query = "SELECT item_id FROM {$this->_wpdb->prefix}{$this->item_table} AS I WHERE 1=1 ";
		}

		// Setup search criteria
		if(! empty($search_args['search'])){
			$search_query .= $this->_wpdb->prepare(" AND `title` LIKE %s ", '%'.$search_args['search'].'%');
		}

		if(! empty($search_args['min'])){
			$search_query .= $this->_wpdb->prepare(" AND `price` >= %d ", $search_args['min']);
		}

		if(! empty($search_args['max'])){
			$search_query .= $this->_wpdb->prepare(" AND `price` <= %d ", $search_args['max']);
		}

		if(! empty($search_args['type'])){
			$search_query .= $this->_wpdb->prepare(" AND `type_id` = %d ", $search_args['type']);
		}

		if(! empty($search_args['subtype'])){
			$search_query .= $this->_wpdb->prepare(" AND `subtype_id` = %d ", $search_args['subtype']);
		}

		if(! empty($search_args['listing'])){
			$search_query .= $this->_wpdb->prepare(" AND `listing_id` = %d ", $search_args['listing']);
		}

		// Setup default values
		$offset = empty($search_args['offset'])?0:$search_args['offset'];
		$count = empty($search_args['count'])?12:$search_args['count'];

		$column = 'item_id';
		$order = 'desc';

		if(! empty($search_args['sortBy'])){
			$sort = explode('-',$search_args['sortBy']);
			
			if($sort[0]){
				switch($sort[0]){
					case 'date':
						$column = 'item_id';
					break;
					case 'name':
						$column = 'title';
					break;
					case 'price':
						$column = 'price';
					break;
					default:
						$column = 'item_id';
				}
			}

			if($sort[1]){
				switch($sort[1]){
					case 'desc':
						$order = 'DESC';
					break;
					case 'asc':
						$order = 'ASC';
					break;
					default:
						$order = 'DESC';
				}
			}

		}

		$order = ' ORDER BY '.$column.' '.$order;

		// ALL matches found with this query
		$matches = $this->_wpdb->get_results($search_query);

		// $this->print_wpdb_errors();

		$max = count($matches);

		// The matches being returned based on an offset of the total results
		$items = $this->_wpdb->get_results(
				$this->_wpdb->prepare("SELECT {$this->image_columns} FROM {$this->_wpdb->prefix}{$this->item_table} AS I
										LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P ON P.item_id = I.item_id AND P.featured = 1
										LEFT JOIN {$this->_wpdb->prefix}{$this->types_table} AS T USING(`type_id`)
										LEFT JOIN {$this->_wpdb->prefix}{$this->user_location} AS UL USING(`user_id`)
										WHERE I.item_id IN ({$search_query})
										{$order}
										LIMIT %d, %d", $offset, $count)
				);

		// $this->print_wpdb_errors();

		return array('items' => $items, 'max' => $max);
	}


	/**
	 * Get the X nearest items based on a specific location
	 * 
	 * @link http://www.plumislandmedia.net/mysql/haversine-mysql-nearest-loc/
	 * 
	 * @param int $city The city being searched
	 * @param int $state The state being searched
	 * @param int $radius The distance from the location to check
	 * @param int $count The number of events to get from the DB
	 * 
	 * @return array A list of the most recent events
	 */
	// public function get_nearest_items($city = '', $state = '', $offset = 0, $radius = 50.0, $count = 12){
		
	// 	$location = $this->get_cached_location($city, $state);
	// 	$user_sql = $this->get_users_by_radius_sql($location, $radius);

	// 	// So this is a bit of a beast but basically we are doing a search based on the lat, lng of the user. We are adding in some constraints which help us from running this calculation on the entire table and instead just on the rows that meet the lat, lng constraint
	// 	$radius_sql = $this->_wpdb->prepare("SELECT item_id FROM {$this->_wpdb->prefix}{$this->item_table} AS I
	// 						LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P USING(item_id)
	// 						LEFT JOIN {$this->_wpdb->prefix}{$this->types_table} AS T USING(`type_id`)
	// 						LEFT JOIN {$this->_wpdb->prefix}{$this->user_location} AS L USING(`user_id`)
	// 						WHERE I.user_id IN ({$user_sql})
	// 						LIMIT %d, %d", intval($offset), intval($count));
		
	// 	return $radius_sql;

	// 	//$items = $this->_wpdb->get_results( $this->_wpdb->prepare($radius_sql, intval($offset), intval($count)) );

	// 	// $this->print_wpdb_errors();

	// 	// return array('items' => $items, 'max' => $max);
	// }


	/**
	 * Get all of the Marketplace types
	 */
	public function get_types(){
		return $this->_wpdb->get_results("SELECT * FROM {$this->_wpdb->prefix}{$this->types_table} ORDER BY `type` ASC");
	}


	/**
	 * Get all of the Marketplace subtypes
	 */
	public function get_subtypes(){
		return $this->_wpdb->get_results("SELECT * FROM {$this->_wpdb->prefix}{$this->subtypes_table} ORDER BY `type` ASC");
	}


	/**
	 * Get all of the Marketplace listing types
	 */
	public function get_listing_types(){
		return $this->_wpdb->get_results("SELECT * FROM {$this->_wpdb->prefix}{$this->listing_type_table} ORDER BY `type` ASC");
	}

}