
<?php 
/**
 * This Class will be used as the model for our Event information
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is an event table diagram for reference
 */

require_once('Base.php');

class Event extends Base {
	protected $_event_id = 0;

	protected $event_table = 'event';
	protected $venue_table = 'event_venues';
	protected $types_table = 'event_types';
	protected $images_table = 'event_images';

	public $info = array();

	/**
	 * Build our event
	 */
	public function __construct($event_id, $wpdb, $debug = false){
		parent::__construct($wpdb, $debug);
		$this->_event_id = $event_id;
	}


	/**
	 * Get the last X events from the database. Ordered by creation date.
	 * 
	 * @param int $count The number of events to get from the DB
	 * 
	 * @return array A list of the most recent events
	 */
	public function get_latest_events($count = 9){
		$result = $this->_wpdb->get_results(
				$this->_wpdb->prepare("SELECT * FROM {$this->_wpdb->prefix}{$this->event_table} AS E
										LEFT JOIN {$this->_wpdb->prefix}{$this->venue_table} AS V USING(venue_id)
										LEFT JOIN {$this->_wpdb->prefix}{$this->images_table} AS I USING(event_id)
										ORDER BY created DESC
										LIMIT %d", $count)
				);

		return $result;
	}


	/**
	 * Get the X nearest events based on a specific location
	 * 
	 * @link http://www.plumislandmedia.net/mysql/haversine-mysql-nearest-loc/
	 * 
	 * @param int $city The city being searched
	 * @param int $state The state being searched
	 * @param int $radius The distance from the location to check
	 * @param int $count The number of events to get from the DB
	 * 
	 * @return array A list of the most recent events
	 */
	public function get_nearest_events($city = '', $state = '', $radius = 50.0, $count = 4){
		
		// First let's try to just do a simple city, state search. If we don't get all the results we want we will have to do a radius search
		$sql = "SELECT * FROM {$this->_wpdb->prefix}{$this->event_table} AS E
				LEFT JOIN {$this->_wpdb->prefix}{$this->venue_table} AS V USING(venue_id)
				LEFT JOIN {$this->_wpdb->prefix}{$this->images_table} AS I USING(event_id)";

		if(! empty($city)){
			$sql .= " WHERE city = '".$city."' ";

			if(! empty($state)){
				$sql .= " AND state = '".$state."' ";
			}
		}

		$sql .= "ORDER BY created DESC
					LIMIT %d";

		$results = $this->_wpdb->get_results( $this->_wpdb->prepare($sql, $count) );

		$count = $count - count($results);

		// Often a radius of 0 will be passed and it means we want to search a wide area
		if(empty($radius)){
			$radius = $this->$radius; // This value may need to be tested more
		}

		if($count > 0){
			$not_in = [];
			foreach($results as $result){
				$not_in[] = $result->event_id;
			}

			$location = $this->get_cached_location($city, $state);

			// So this is a bit of a beast but basically we are doing a search based on the lat, lng of the user. We are adding in some constraints which help us from running this calculation on the entire table and instead just on the rows that meet the lat, lng constraint
			$radius_sql = "SELECT * FROM {$this->_wpdb->prefix}{$this->event_table} AS E
								LEFT JOIN {$this->_wpdb->prefix}{$this->venue_table} AS V USING(venue_id)
								LEFT JOIN {$this->_wpdb->prefix}{$this->images_table} AS I USING(event_id)
								WHERE E.venue_id IN (
									SELECT venue_id
									FROM (
										SELECT EV.venue_id,
											EV.lat, 
											EV.lng,
											p.radius,
											p.distance_unit
												* DEGREES(ACOS(COS(RADIANS(p.latpoint))
												* COS(RADIANS(EV.lat))
												* COS(RADIANS(p.longpoint - EV.lng))
												+ SIN(RADIANS(p.latpoint))
												* SIN(RADIANS(EV.lat)))) AS distance
										FROM {$this->_wpdb->prefix}{$this->venue_table} AS EV 
										JOIN (   
											SELECT  {$location['lat']} AS latpoint, {$location['lng']} AS longpoint, %s AS radius, 111.045 AS distance_unit
										) AS p ON 1=1
										WHERE EV.lat
											BETWEEN p.latpoint  - (p.radius / p.distance_unit)
												AND p.latpoint  + (p.radius / p.distance_unit)
											AND EV.lng
											BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
												AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
										) AS d
									WHERE distance <= radius
									ORDER BY distance
								)";

			if(! empty($not_in)){
				$radius_sql .= " AND E.event_id NOT IN (".implode(',',$not_in).") ";
			}

			$radius_sql .=  "LIMIT %d";
			
			$results = array_merge($results, $this->_wpdb->get_results( $this->_wpdb->prepare($radius_sql, $radius, $count) ));
		}

		// $this->print_wpdb_errors();

		return $results;
	}



	/**
	 * Get this events basic information
	 * 
	 * @param int $event_id The ID of the event making the query
	 */
	public function get_info(){
		$this->info = $this->_wpdb->get_row($this->_wpdb->prepare("SELECT * FROM {$this->_wpdb->prefix}{$this->event_table} WHERE `event_id` = %d", $this->_event_id));

		return $this->info;
	}


	/**
	 * Update this events information
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return bool The result of the update query. === false means fail but === 0 means no rows updated
	 */
	public function update_info($info){

		$info = $this->clean_info($info, array('event_id'));

		$result = $this->_wpdb->update(
			$this->_wpdb->prefix.$this->event_table,
			(array)$info, //by default out info is in Object form. So let's convert that to an array for updating
			array(
				'event_id' => $this->_event_id
			)
		);

		if($result === false && $this->_debug){
			// Error occured
			die('update error: '+$this->_wpdb->last_error);
		}else{
			return $result;
		}
	}


	/**
	 * Create a new event
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return int The ID of the event that was just created
	 */
	public function create_event($info){

		$info = $this->clean_info($info, array('event_id'));

		$result = $this->_wpdb->insert(
			$this->_wpdb->prefix.$this->event_table,
			(array)$info //by default out info is in Object form. So let's convert that to an array for updating
		);

		if($result === false && $this->_debug){
			// Error occured
			die('create error: '+$this->_wpdb->last_error);
		}else{
			return $this->_wpdb->insert_id;
		}

	}


}