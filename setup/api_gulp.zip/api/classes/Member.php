
<?php 
/**
 * This Class will be used as the model for our MadCity Users information in the Admin, Account Pages, and API
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is a user table diagram for reference
 */

require_once('User.php');

class Member extends User {

	protected $member_table = 'member';
	protected $horse_table = 'horse';
	protected $interests_table = 'member_interests';

	public function __construct($user_id, $wpdb, $debug = false) {
		parent::__construct($user_id, $wpdb, $debug);
	}

	/**
	 * Set this users member information
	 */
	public function set_member_info(){
		$this->info = $this->_wpdb->get_row($this->_wpdb->prepare("SELECT MT.*, U.*, P.*, COUNT(H.horse_id) AS horse_count FROM {$this->_wpdb->prefix}{$this->member_table} as MT 
																	LEFT JOIN {$this->_wpdb->users} AS U ON MT.user_id = U.ID
																	LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P USING(`user_id`)
																	LEFT JOIN {$this->_wpdb->prefix}{$this->horse_table} AS H USING(`user_id`)
																	WHERE U.ID = %d", $this->_user_id));
	}


	/**
	 * Update this users information
	 * 
	 * TODO: Need to update this function to work with multiple tables for different data
	 * 
	 * @param int $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 */
	public function update_member_info($info){

		return $this->update_info($info, $this->member_table);

	}


	/**
	 * Get the last X members from the database. Ordered by creation date.
	 * 
	 * @param int $count The number of items to get from the DB
	 * 
	 * @return array A list of the most recent members to register
	 */
	public function get_latest_members($count = 8){

		$result = $this->_wpdb->get_results(
				$this->_wpdb->prepare("SELECT MT.*, U.*, P.*, A.*, COUNT(H.horse_id) AS horse_count FROM {$this->_wpdb->prefix}{$this->member_table} as MT
										LEFT JOIN {$this->_wpdb->users} AS U ON MT.user_id = U.ID
										LEFT JOIN {$this->_wpdb->prefix}{$this->image_table} AS P USING(`user_id`)
										LEFT JOIN {$this->_wpdb->prefix}{$this->horse_table} AS H USING(`user_id`)
										LEFT JOIN {$this->_wpdb->prefix}{$this->activity_table} AS A USING(`user_id`)
										WHERE A.active = 1
										GROUP BY MT.user_id
										ORDER BY U.user_registered DESC
										LIMIT %d", $count)
				);

		// $this->print_wpdb_errors();

		return $result;
	}

}