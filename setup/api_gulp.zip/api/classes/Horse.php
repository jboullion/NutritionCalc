
<?php 
/**
 * This Class will be used as the model for our Horse information
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is a horse table diagram for reference
 */

require_once('Base.php');

class Horse extends Base {
	protected $_horse_id = 0;

	protected $horse_table = 'horse';
	protected $breeds_table = 'horse_breeds';
	protected $coat_color_table = 'horse_coat_color';
	protected $gender_table = 'horse_gender';
	protected $rider_ability_table = 'horse_rider_ability';
	protected $rider_activities_table = 'horse_rider_activities';
	protected $temperment_table = 'horse_temperment';
	protected $training_table = 'horse_training';
	protected $types_table = 'horse_types';

	/**
	 * Build our horse
	 */
	public function __construct($horse_id, $wpdb, $debug = false){
		parent::__construct($wpdb, $debug);
		$this->_horse_id = $horse_id;
	}


	/**
	 * Get this horses basic information
	 * 
	 * @param int $horse_id The ID of the horse making the query
	 */
	public function get_info(){
		// if(empty($this->info)){
			$this->info = $this->_wpdb->get_row($this->_wpdb->prepare("SELECT * FROM {$this->_wpdb->prefix}{$this->horse_table} WHERE `horse_id` = %d", $this->_horse_id));
		// }

		// unset($info->horse_id);

		return $this->info;
	}


	/**
	 * Update this horses information
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return bool The result of the update query. === false means fail but === 0 means no rows updated
	 */
	public function update_info($info){

		// make sure we don't have a horse_id already attached
		if(is_array($info)){
			unset($info['horse_id']);
		}elseif($info->horse_id){
			unset($info->horse_id);
		}

		$result = $this->_wpdb->update(
			$this->_wpdb->prefix.$this->horse_table,
			(array)$info, //by default out info is in Object form. So let's convert that to an array for updating
			array(
				'horse_id' => $this->_horse_id
			)
		);

		if($result === false && $this->_debug){
			// Error occured
			die('update error: '+$this->_wpdb->last_error);
		}else{
			return $result;
		}
	}


	/**
	 * Create a new horse
	 * 
	 * @param array $info An array of information based on the info array returned from get_info() Can also be an array of just the columns that need updating
	 *
	 * @return int The ID of the horse that was just created
	 */
	public function create_horse($info){

		// make sure we don't have a horse_id already attached
		if(is_array($info)){
			unset($info['horse_id']);
		}elseif($info->horse_id){
			unset($info->horse_id);
		}

		$result = $this->_wpdb->insert(
			$this->_wpdb->prefix.$this->horse_table,
			(array)$info //by default out info is in Object form. So let's convert that to an array for updating
		);

		if($result === false && $this->_debug){
			// Error occured
			die('create error: '+$this->_wpdb->last_error);
		}else{
			return $this->_wpdb->insert_id;
		}

	}


}