
<?php 
/**
 * This Class contains various utility functions and variables that are used in every other (or most other) classes
 * If you notice you are using the same variable or function in multiple sites it might be worth moving it here
 * 
 * @link https://dbdiagram.io/d/5e39f5809e76504e0ef109a9 Here is a item table diagram for reference
 */

class Base {
	protected $_wpdb;
	protected $_debug = false;

	protected $info = array();

	protected $locations_table = 'location_cache';
	protected $user_location = 'user_location';
	protected $user_images = 'user_images';

	protected $radius = 200.00;

	protected $mapquest_key = 'H2ERAdMPjGuKakxemA1agSSvRCYjTIH6';
	protected $google_key = 'AIzaSyDKK63ADAJUez9w8JmRXSsBCUikNXVU2KQ';

	// protected $distance_unit = 111.045; // This is 1 degree between lat / lng lines. Used to limit the query 

	/**
	 * Build our item
	 */
	protected function __construct($wpdb, $debug = false){
		$this->_wpdb = $wpdb;
		$this->_debug = $debug;
	}

	/**
	 * Return the lat / lng of a previously cached location. This helps to reduce our reliance on MapQuest / Google Maps
	 * 
	 * @param string $city The name of the city we are searching for
	 * @param string $state The name of the state we are searching in
	 * 
	 * @return array The lat, lng of the requested city, state
	 */
	protected function get_cached_location($city, $state){

		$location = $this->_wpdb->get_row(
			$this->_wpdb->prepare("SELECT lat, lng FROM {$this->_wpdb->prefix}{$this->locations_table} WHERE `city` = %s AND `state` = %s", $city, $state), ARRAY_A
		);

		if(empty($location)){
			$location = array();

			$mapquest_result = json_decode($this->file_get_contents_curl('http://open.mapquestapi.com/geocoding/v1/address?key='.$this->mapquest_key.'&location='.$city.','.$state));

			// $this->pk_print($mapquest_result);

			if(! empty($mapquest_result)
			&& ! empty($mapquest_result->results[0]->locations[0]->latLng->lat)){
				// We found something so let's setup our lat, lng and also save it to our cache table

				$location['lat'] = $mapquest_result->results[0]->locations[0]->latLng->lat;
				$location['lng'] = $mapquest_result->results[0]->locations[0]->latLng->lng;

				$this->_wpdb->insert(
					$this->_wpdb->prefix.$this->locations_table,
					array(
						'city' => $city,
						'state' => $state,
						'lat' => $location['lat'],
						'lng' => $location['lng'],
					)
				);
			}
		}

		// $this->pk_print($location);

		return $location;

	}

	/**
	 * Used to search users by radius. Various things are related to users and their location so this query will likely be used mostly inside of other functions to get items, members, clubs, business near a certain location
	 * 
	 * @link http://www.plumislandmedia.net/mysql/haversine-mysql-nearest-loc/
	 * 
	 * @param array $location An array containing (city, state, lat, lng) also a row from the location_cache table
	 * @param float $radius How far in each direction from the location should we search
	 * 
	 * @return string the SQL needed to search for users by radius
	 */
	protected function get_users_by_radius_sql($location, $radius = 0){ //($city, $state){

		// Often a radius of 0 will be passed and it means we want to search a wide area
		if(empty($radius)){
			$radius = $this->$radius; // This value may need to be tested more
		}

		$user_sql = $this->_wpdb->prepare("SELECT `user_id`
											FROM (
												SELECT UL.user_id,
													UL.lat, 
													UL.lng,
													p.radius,
													p.distance_unit
														* DEGREES(ACOS(COS(RADIANS(p.latpoint))
														* COS(RADIANS(UL.lat))
														* COS(RADIANS(p.longpoint - UL.lng))
														+ SIN(RADIANS(p.latpoint))
														* SIN(RADIANS(UL.lat)))) AS distance
												FROM {$this->_wpdb->prefix}{$this->user_location} AS UL 
												JOIN (   
													SELECT  {$location['lat']} AS latpoint, 
															{$location['lng']} AS longpoint, 
															%s AS radius, 
															111.045 AS distance_unit
												) AS p ON 1=1
												WHERE UL.lat
													BETWEEN p.latpoint  - (p.radius / p.distance_unit)
														AND p.latpoint  + (p.radius / p.distance_unit)
													AND UL.lng
													BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
														AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
												) AS d
											WHERE distance <= radius
											ORDER BY distance", floatval($radius));

		return $user_sql; // $this->_wpdb->get_results( $this->_wpdb->prepare($sql, $count) );
	}


	/**
	 * Helper function to print data cleanly
	 * 
	 * @param mixed $data Any value that you want to print
	 */
	protected function pk_print($data){
		echo '<pre class="pk-print">'.print_r($data,true).'</pre>';
	}


	/**
	 * Do any parsing or processing of the info so it can be consumed by the database correctly
	 */
	protected function clean_info($info, $keys = array()){
		// make sure we don't have a event_id already attached
		if(is_array($info)){
			foreach($keys as $key){
				unset($info[$key]);
			}
		}elseif($info->event_id){
			foreach($keys as $key){
				unset($info->{$key});
			}
		}

		return $info;
	}


	/**
	 * Display the last couple errors from WPDB
	 */
	protected function print_wpdb_errors(){
		$this->pk_print($this->_wpdb->last_query);
		$this->pk_print($this->_wpdb->last_error);
	}


	/**
	 * Since we can't be guaranteed to have file_get_contents we are setting up a replacement function that should always work
	 * 
	 * @param string $url The url to get the contents of
	 * 
	 * @return mixed The result of the curl request
	 */
	protected function file_get_contents_curl($url) {
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       

		$data = curl_exec($ch);
		curl_close($ch);

		return $data;
	}


}