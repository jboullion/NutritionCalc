<?php
/**
 * Get Horse Information
 */
require_once('horse-setup.php');

if(empty($_POST['horse_id']) || ! is_numeric($_POST['horse_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$Horse = new Horse($_POST['horse_id'], $wpdb);

$horse_info = $Horse->get_info();

if(! empty($horse_info)){
	echo json_encode($horse_info);
}else{
	echo json_encode(array('error'=> 'Unable to get horse information'));
}

exit();
