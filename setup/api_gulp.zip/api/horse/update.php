<?php
/**
 * Update Horse Information
 */
require_once('horse-setup.php');

if(empty($_POST['horse_info']) || ! is_array($_POST['horse_info']) 
|| empty($_POST['horse_info']['horse_id']) || ! is_numeric($_POST['horse_info']['horse_id'])) {
	echo json_encode(array('error'=> 'horse information missing'));
	exit;
}

$Horse = new Horse($_POST['horse_info']['horse_id'], $wpdb);

$result = $Horse->update_horse_info($_POST['horse_info']);

if($result !== false){
	echo json_encode(array('success'=> 'Horse Updated!'));
}else{
	echo json_encode(array('error'=> 'Unable to update horse information'));
}

exit();
