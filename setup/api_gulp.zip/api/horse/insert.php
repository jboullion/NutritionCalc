<?php
/**
 * Update Horse Information
 */
require_once('horse-setup.php');

if(empty($_POST['horse_info']) || ! is_array($_POST['horse_info'])) {
	echo json_encode(array('error'=> 'horse information missing'));
	exit;
}

$Horse = new Horse(0, $wpdb);

$horse_id = $Horse->create_horse($_POST['horse_info']);

if($horse_id !== false){
	echo json_encode(array('success'=> 'Horse Updated!', 'horse_id' => $horse_id));
}else{
	echo json_encode(array('error'=> 'Unable to insert horse information'));
}

exit();
