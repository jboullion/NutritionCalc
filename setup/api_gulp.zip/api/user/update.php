<?php
/**
 * Update User Information
 */
require_once('user-setup.php');

if(empty($_POST['user_id']) || ! is_numeric($_POST['user_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

if(empty($_POST['user_info']) || ! is_array($_POST['user_info'])) {
	echo json_encode(array('error'=> 'User information missing'));
	exit;
}

$USER = new MadCityUser($_POST['user_id'], $wpdb);

$result = $USER->update_user_info($_POST['user_info']);

if($result !== false){
	echo json_encode(array('success'=> 'User Updated!'));
}else{
	echo json_encode(array('error'=> 'Unable to get user information'));
}

exit();
