<?php
/**
 * Get User Information
 */
require_once('user-setup.php');

if(empty($_POST['user_id']) || ! is_numeric($_POST['user_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$USER = new MadCityUser($_POST['user_id'], $wpdb);

$user_info = $USER->get_user_info();

if(! empty($user_info)){
	echo json_encode($user_info);
}else{
	echo json_encode(array('error'=> 'Unable to get user information'));
}

exit();
