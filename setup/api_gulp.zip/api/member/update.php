<?php
/**
 * Update Agent Information
 */

require_once('agent-setup.php');

//pk_print(json_decode(array_key_first($_REQUEST)));
//pk_print($_REQUEST);

if(empty($_GET['agent_id']) || ! is_numeric($_GET['agent_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$AGENT = new MadCityAgent($_GET['agent_id'], $wpdb);

$agent_update = $AGENT->update_agent($_GET, $_GET['agent_id']);

if(! empty($agent_update)){
	echo json_encode(array('success' => $agent_update));
}else{
	echo json_encode(array('error' => 'Unable to get user information'));
}

exit();