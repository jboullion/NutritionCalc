<?php
/**
 * Get All Agents
 */

require_once('agent-setup.php');

$agents = $wpdb->get_results("SELECT * FROM {$agent_table} WHERE active = 1 ORDER BY last_name, first_name ASC");

if(! empty($agents)){
	echo json_encode($agents);
}else{
	echo json_encode(array('error'=> 'Unable to get agent information'));
}

exit();