<?php 

// Gather all the prerequsistes for our User API calls
require_once('../api-setup.php');
require_once('../classes/Member.php');