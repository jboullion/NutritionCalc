<?php
/**
 * Update a new Agent image
 * 
 * This script will also create a 150x150 thumbnail of said image and set that thumbail as the img for the specified agent
 */
require_once('agent-setup.php');

if( empty($_FILES['agentImg']) || empty($_REQUEST['agent_id']) || ! is_numeric($_REQUEST['agent_id'])){
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$check = getimagesize($_FILES["agentImg"]["tmp_name"]);
$upload = false;

if($check !== false) {

	// We are loading this into our react public folder. These images will be moved outside of react to the "static" folder at the root when we build the production version of our app
	if(ENVIRONMENT != 'live'){
		$target_dir = "../../gulp/react/madcity/public/assets/img/avatars/";
	}else{
		$target_dir = "../../assets/img/avatars/";
	}

	$filename = basename($_FILES["agentImg"]["name"]);
	$target_file = $target_dir . $filename;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

	// Allow certain file formats
	if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
	&& $imageFileType != "gif" ) {
		echo json_encode(array('error'=> 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.'));
		exit();
	}else{
		// Upload our file to our server
		move_uploaded_file($_FILES["agentImg"]['tmp_name'], $target_file);

		// Resize our image 
		if (true !== ($pic_error = @pk_image_resize($target_file, $target_dir . "150x150{$filename}", 150, 150, 1))) {
			//echo $pic_error;
			unlink($target_file);
			echo json_encode(array('error'=> $pic_error));
		} else {
			$avatar_loc = '/assets/img/avatars/150x150'.$filename;
			echo json_encode(array('success'=> 1, 'img'=> $avatar_loc));
			
			// Update our agent's avatar img url
			$wpdb->update(
				$wpdb->prefix.'agent_data',
				array(
					'img' => $avatar_loc
				),
				array(
					'agent_id' => $_REQUEST['agent_id']
				)
			);
		}
		exit();
	}

} else {
	echo json_encode(array('error'=> 'File is not an image.'));
	exit();
}

if(! $upload){
	echo json_encode(array('error'=> 'Unable to get agent information'));
}

exit();