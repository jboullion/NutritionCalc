<?php
/**
 * Get Agent Information
 */
require_once('agent-setup.php');

if(empty($_GET['agent_id']) || ! is_numeric($_GET['agent_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$AGENT = new MadCityAgent($_GET['agent_id'], $wpdb);

$agent_info = $AGENT->get_agent_info();

if(! empty($agent_info)){
	echo json_encode($agent_info);
}else{
	echo json_encode(array('error'=> 'Unable to get user information'));
}

exit();