<?php
/**
 * This script will setup everything we need for our individual API endpoints. Mostly the $wpdb object and the api-functions
 * 
 * TODO: Move this API to the site root instead of the theme. This should make things easier all around.
 */

error_reporting(E_ALL);
@ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
//header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

header("Content-Type: application/json; charset=UTF-8");
header('Cache-Control: max-age=0'); //prevent returning cached data

date_default_timezone_set("America/Chicago");

//By using a SHORTINIT and loading WP we are ONLY loading our database object ($wpdb).
define('SHORTINIT', true);
require_once(dirname(__FILE__) .'/../wp-load.php');
require_once('api-functions.php');

global $wpdb;