<?php 
/**
 * Get a Single Item's information
 */
require_once('marketplace-setup.php');

if(empty($_POST['item_id']) || ! is_numeric($_POST['item_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$search_args = $_POST?$_POST:array();

$MarketItem = new MarketItem($_POST['item_id'], $wpdb);

$items = $MarketItem->get_related_items($search_args);

if(! empty($items)){
	echo json_encode($items);
}else{
	echo json_encode(array('error'=> 'Unable to load items'));
}

exit();
