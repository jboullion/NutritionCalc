<?php 
/**
 * Get a Single Item's information
 */
require_once('marketplace-setup.php');

if(empty($_POST['item_id']) || ! is_numeric($_POST['item_id'])) {
	echo json_encode(array('error'=> 'Missing Information'));
	exit;
}

$MarketItem = new MarketItem($_POST['item_id'], $wpdb);

$item = $MarketItem->get_info();

if(! empty($item)){
	// Turn our description into better displayed HTML. We are not allowing HTML into the DB for security reasons
	if(! empty($item->desc)){
		$item->desc = "<p>" . preg_replace("/(\r\n|\n\r|\n\n)/", "</p><p>", $item->desc). "</p>";
	}

	// Return easier to read dates and times
	if(! empty($item->created)){
		$item->created = date('n / j / Y', strtotime($item->created));
		$item->created_time = date('h:ia', strtotime($item->created));
	}

	$images = $MarketItem->get_images();

	if(! empty($images)){
		$item->images = $images;
	}

	echo json_encode($item);
}else{
	echo json_encode(array('error'=> 'Unable to load items'));
}

exit();
