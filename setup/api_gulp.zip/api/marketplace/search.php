<?php
/**
 * Search the Marketplace and return the results
 */
require_once('marketplace-setup.php');

// These values are cleaned in the query
$search_args = $_POST?$_POST:array();

$MarketItem = new MarketItem(0, $wpdb);

$items = $MarketItem->search_items($search_args);

if(! empty($items)){
	echo json_encode($items);
}else{
	echo json_encode(array('error'=> 'Unable to load items'));
}

exit();
