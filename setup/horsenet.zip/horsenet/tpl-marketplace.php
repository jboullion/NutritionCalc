<?php
	/* Template Name: Marketplace Template */
	get_header(); 
	the_post();

	require_once ABSPATH.'/api/classes/MarketItem.php';

	pk_set('fields', get_fields());
?>
<div id="marketplace" class="page">
	<?php get_template_part('templates/marketplace/left'); ?>
	<?php get_template_part('templates/marketplace/right'); ?>
</div>
<?php 
	get_template_part('templates/modals/location');
	get_template_part('templates/marketplace/controller');
	get_template_part('includes/owl-carousel');
	get_template_part('includes/photoswipe');
	get_footer('marketplace');