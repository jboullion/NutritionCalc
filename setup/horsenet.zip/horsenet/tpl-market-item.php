<?php
	/* Template Name: Market Item Template */
	get_header(); 
	the_post();

	pk_set('fields', get_fields());

	pk_print($_GET);

	// This is the item id we are displaying
	$item_id = get_query_var('page');
	// $item_id = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

	pk_print($item_id);

?>
<div id="item-page" class="page">
	<?php //get_template_part('templates/home/featured'); ?>
</div>
<?php 
	get_footer();