<?php
	/* Template Name: Homepage Template */
	get_header(); 
	the_post();

	$fields = get_fields();
	pk_set('fields', $fields);
?>
<div id="home-page" class="page">
	<?php get_template_part('templates/home/featured'); ?>

	<div id="benefits-background-wrapper">
		<div id="benefits-background" class="setup-background lazy" data-src="<?php echo $fields['benefits_background']['sizes']['large']; ?>"></div>
		<?php get_template_part('templates/home/marketplace', 'latest'); ?>

		<?php get_template_part('templates/home/benefits'); ?>

		<?php get_template_part('templates/home/members', 'latest'); ?>
	</div>

	<?php get_template_part('templates/home/events'); ?>

	<?php get_template_part('templates/home/find', 'business'); ?>

</div>
<?php get_template_part('includes/owl-carousel'); ?>
<?php 
	get_footer();