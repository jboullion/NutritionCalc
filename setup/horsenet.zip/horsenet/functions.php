<?php
	// includes all flags for certain theme support
	include('includes/theme-support.php');

	// includes all of the default powderkeg functions and functionality
	include('pk/functions.php');

	// includes any menu walkers
	include('includes/walkers.php');

	// Setup the site with defaults and standard WP changes
	include('includes/setup.php');

	// Various helper functions
	include('includes/helpers.php');

	// Functions used to display pieces of code
	include('includes/display.php');

	// Common WP Engine functions
	// include('includes/wpengine.php');

	add_action( 'after_setup_theme', 'pk_set_image_sizes' );
	function pk_set_image_sizes() {
		// image sizes
		#add_image_size('extra-large', 1900, 1400, false);
		#add_image_size('image-960-480c', 960, 480, true);
	}

	//putting Googlt Fonts in the footer improves pagespeed rankings
	add_action('get_footer', 'pk_theme_enqueue_fonts', 10);
	//if you are noticing a brief delay before fonts loads (usually when loading multiple fonts) you can load in the header to prevent flash, but take a hit on pagespeed rankings
	//add_action('get_header', 'pk_theme_enqueue_fonts', 10);
	function pk_theme_enqueue_fonts() {
		// Import Google Web Fonts
		$fonts = array(
				'Poppins' => '400,700',
				'Raleway' => '400,700',
				'Inria Serif' => '400,700'
			);

		pk_webfont($fonts);
	}

	add_action('init', 'pk_register_cpts');
	function pk_register_cpts() {
		// found in pk/functions/common.php 
		// quickly create most custom post types.
		#pk_register_cpt(array('name' => 'video', 'icon' => 'dashicons-format-video', 'position' => 30, 'exclude_from_search' => true, 'rewrite' => array( 'slug' => 'seminars-videos/videos') ));
	}
