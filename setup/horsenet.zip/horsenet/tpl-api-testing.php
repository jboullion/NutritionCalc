<?php
	/* Template Name: API Testing */
	get_header(); 
	the_post();
?>
<div id="api-page" class="page">
	<?php get_template_part('templates/common/content'); ?>
</div>
<script>
jQuery(document).ready(function($){
	var horse_id = 1;
	var horse = null;

	// var user_info = <?php echo json_encode($user_info); ?>;
	// $.post( '/api/user/update', {user_id: 1, user_info}, function( data ) {
	// 	if(data.error){
	// 		console.log(data.error);
	// 	}else{
	// 		console.log(data);
	// 	}
	// }, "json");

	// setupHorse(horse_id);

	/**
	 * Setup a horse, this will get a horse information from the database and set the information in the correct place
	 * 
	 * @param int horse_id The id of the horse to retrieve from the DB
	 */
	function setupHorse(horse_id){
		$.post( '/api/horse/get', {horse_id: horse_id}, function( data ) {
			if(data.error){
				console.log(data.error);
			}else{
				console.log(data);
				horse = data
				// updateHorse(horse);
				// createHorse(horse);
			}
		}, "json");
	}

	/**
	 * Update a horse! Just pass in the info you want to update the horse with.
	 * 
	 * @param Object horse The object that you would like to turn into a horse in the DB
	 */
	function updateHorse(horse){
		horse.registered_name = 'You have been updated'

		$.post( '/api/horse/update', {horse_info: horse}, function( data ) {
			if(data.error){
				console.log(data.error);
			}else{
				console.log(data);
				//horse = data
			}
		}, "json");
	}

	/**
	 * Create a horse! Just pass in the info you want to create the horse with.
	 * 
	 * @param Object horse The object that you would like to turn into a horse in the DB
	 */
	function createHorse(horse){
		horse.horse_id = null;
		horse.registered_name = 'Created Horsey';

		$.post( '/api/horse/insert', {horse_info: horse}, function( data ) {
			if(data.error){
				console.log(data.error);
			}else{
				console.log(data);
				//horse = data
			}
		}, "json");
	}
});
</script>
<?php 
	get_footer();