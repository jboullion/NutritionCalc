		<?php get_template_part('templates/common/footer'); ?>
		<?php wp_footer(); ?>
	</body>
</html>