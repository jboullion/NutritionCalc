<?php 
	$fields = pk_get('fields');
	$options = pk_get('options');

	if(empty($fields['benefits_title'])) return;

?>
<section class="wrapper" id="benefits">
	<div class="wide-container">
		<div class="row">
			<div class="col-lg-6 content">
				<?php 
					if(! empty($fields['benefits_supertitle'])){
						echo '<h5>'.$fields['benefits_supertitle'].'</h5>';
					}

					echo '<h1>'.$fields['benefits_title'].'</h1>';

					if(! empty($fields['benefits_text'])){
						echo apply_filters('the_content',$fields['benefits_text']);
					}

					pk_display_pk_button($fields['benefits_button'], 'btn btn-primary');
				?>
			</div>
			<div class="col-lg-6">
				<?php 
					if(! empty($fields['benefits_list'])){
						foreach($fields['benefits_list'] as $benefit){
							echo '<div class="benefit">
									<div class="benefit-icon"><i class="fal not-'.$benefit['icon'].'"></i></div>
									<div class="benefit-content">
										<h3>'.$benefit['title'].'</h3>
										'.apply_filters('the_content',$benefit['text']).'
									</div>
								</div>';
						}
					}
				?>
			</div>
		</div>
	</div>
</section>