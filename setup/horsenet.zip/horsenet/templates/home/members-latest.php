<?php 
	global $wpdb;
	$fields = pk_get('fields');
	$options = pk_get('options');

	require_once ABSPATH.'/api/classes/Member.php';

	$Member = new Member(0, $wpdb);
	$Member->set_member_info();

	$latest_members = $Member->get_latest_members();
?>
<section class="wrapper no-print" id="members-latest" >
	<div class="row">
		<div class="col-12 txt-center">
			<h4>Some of the Latest Members to join the Horse Net</h4>
		</div>
	</div>
	<div class="members">
		<?php 
			foreach($latest_members as $member){
				pk_display_member_card($member);
			}
		?>
	</div>
	<script>
		// jQuery(document).ready(function($){

		// 	$('#member-carousel').owlCarousel({
		// 		stagePadding: 50,
		// 		lazyLoad:true,
		// 		loop: true,
		// 		autoHeight: true,
		// 		margin: 0,
		// 		responsiveClass: true,
		// 		slideBy: 1,
		// 		nav: false,
		// 		dots: false,
		// 		responsive:{
		// 			0:{
		// 				items:1
		// 			},
		// 			500:{
		// 				items:2
		// 			},
		// 			750:{
		// 				items:3
		// 			},
		// 			1000:{
		// 				items:4
		// 			},
		// 			1300:{
		// 				items:5
		// 			},
		// 			1500:{
		// 				items:6
		// 			}
		// 		}
		// 	});

		// });
	</script>
</section>
