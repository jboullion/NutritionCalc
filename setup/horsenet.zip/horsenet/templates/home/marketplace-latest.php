<?php 
	global $wpdb;
	$fields = pk_get('fields');
	$options = pk_get('options');

	require_once ABSPATH.'/api/classes/MarketItem.php';

	$MarketItem = new MarketItem(0, $wpdb);

	$latest_items = $MarketItem->get_latest_items();
?>
<section class="wrapper no-print" id="market-latest" >
	<div class="container">
		<div class="row">
			<div class="col-12 txt-center">
				<h2>Latest Items on the Marketplace</h2>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				<div id="marketplace-carousel" class="owl-carousel">
					<?php 
						foreach($latest_items as $item){
							pk_display_item_card($item);
						}
					?>
				</div>
	
			</div>
		</div>
		<div class="row">
			<div class="col-12 txt-center view-marketplace">
				<h4>Want to see more? <a href="/marketplace/" class="btn btn-primary btn-thin">Visit Marketplace</a></h4> 
			</div>
		</div>
	</div>
	<script>
		jQuery(document).ready(function($){

			$('#marketplace-carousel').owlCarousel({
				loop: false,
				autoHeight: true,
				lazyLoad:true,
				margin: 0,
				responsiveClass: true,
				slideBy: 3,
				nav: true,
				navText: ['<i class="fal fa-angle-left"></i>','<i class="fal fa-angle-right"></i>'],
				dots: true,
				responsive:{
					0:{
						items:1
					},
					550:{
						items:2
					},
					960:{
						items:3
					}
				}
			});

		});
	</script>
</section>