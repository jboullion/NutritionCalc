<?php 
	global $wpdb;
	$fields = pk_get('fields');
	$options = pk_get('options');
?>
<section class="wrapper no-print" id="find-business" >
	<div class="row padding-row">
		<div class="col-lg-8 gray-back"></div>
		<div class="col-lg-4"></div>
	</div>
	<div class="row content-row">
		<div class="col-lg-7 gray-back">
			<?php 
				echo '<h2>'.$fields['find_business_title'].'</h2>';
				echo apply_filters('the_content', $fields['find_business_text']);
			?>
			<form role="search" method="get" action="/events/">
				<div class="col-field service">
					<label for="service">Service?</label>
					<div class="pk-select">
						<select name="service">
							<option value="">Select Service</option>
						</select>
					</div>
				</div>
				<div class="col-field zip">
					<label for="zip">Zip Code</label>
					<input type="text" class="" id="zip" maxlength="10">
				</div>
				<div class="col-field submit">
					<label>&nbsp;</label>
					<button type="submit" class="btn btn-primary"><i class="fas fa-angle-right"></i></button>
				</div>
				
			</form>

			<hr />

			<?php 
				echo apply_filters('the_content', $fields['find_business_sub_text']);
				pk_display_pk_button($fields['find_business_button'], 'btn btn-primary btn-thin');
			?>
			
		</div>
		<div class="col-lg-5 setup-background" style="background-image: url(https://www.phelpssports.com/content/uploads/2019/02/Clydesdales-fb.jpg);">

		</div>
	</div>
	<div class="row padding-row">
		<div class="col-lg-8 gray-back"></div>
		<div class="col-lg-4"></div>
	</div>
</section>