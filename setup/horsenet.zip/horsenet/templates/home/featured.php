<?php 
	$fields = pk_get('fields');
	$options = pk_get('options');

	$featured_image = pk_get_featured_image();
	if(empty($featured_image)){
		$featured_image = $options['default_featured_image']['url'];
	}

if(! empty($featured_image)):

	// $supertitle = $fields['featured_supertitle'];
	// $title = $fields['featured_title'];
	// $subtitle = $fields['featured_subtitle'];
	// $button = $fields['featured_button'];

	// class="lazy" data-src="$featured_image;"
?>
<section class="wrapper no-print" id="featured" >
	<div class="overlay setup-background" style="background-image: url(<?php echo $featured_image; ?>);"></div>
	<div class="container">
		<div class="row">
			<div class="col-12">
				<h5><?php echo $fields['featured_supertitle']; ?></h5>
				<h1><?php echo $fields['featured_title']; ?></h1>
				<p><?php echo $fields['featured_subtitle']; ?></p>
				<?php 
					pk_display_pk_button($fields['featured_button'], 'btn btn-primary');
				?>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>