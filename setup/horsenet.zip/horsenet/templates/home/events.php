<?php 
	global $wpdb;
	$fields = pk_get('fields');
	$options = pk_get('options');

	//require_once ABSPATH.'/api/classes/Events.php';

	//$Event = new Event(0, $wpdb);

	//$latest_events = $Event->get_nearest_events('verona', 'wi');

	// TODO: Need to update this to get the nearest events and to do some checks when displaying to make sure we always have 4 events OR we don't try to display empty events
	// TODO: Need to turn this into a JS event where the events are loaded dynamically since we will be caching the page but these events need to be unique to each person
?>
<section class="wrapper no-print" id="events" >
	<div class="container">
		<div class="row event-form">
			<div class="col-lg-8">
				<form role="search" method="get" action="/events/">
					<label class="h2">Upcoming Events in</label>
					<div class="input-group">
						<input type="search" class="user-city form-control" value="" name="sevents" title="Your City" required />
						<div class="input-group-append">
							<button type="submit" class="btn"><i class="far fa-search"></i></button>
						</div>
					</div>
				</form>
			</div>
			<div class="col-lg-4">
				<a href="/events/" class="btn btn-primary alignright">View All Events</a>
			</div>
		</div>
		<div class="row top-events">
			<div class="col-md-6" id="event-1"></div>
			<div class="col-md-6" id="event-2"></div>
			<?php 
				//foreach($latest_events as $event){
					// echo '<div class="col-md-6">';
					// pk_display_event_card($latest_events[0]);
					// echo '</div>';

					// echo '<div class="col-md-6">';
					// pk_display_event_card($latest_events[1]);
					// echo '</div>';
				//}
			?>
		</div>
		<div class="row bottom-events">
			<div class="col-md-6 col-lg-4" id="event-3"></div>
			<div class="col-md-6 col-lg-4" id="event-4"></div>

			<?php 
				// echo '<div class="col-md-6 col-lg-4">';
				// pk_display_event_card($latest_events[2]);
				// echo '</div>';

				// echo '<div class="col-md-6 col-lg-4">';
				// pk_display_event_card($latest_events[3]);
				// echo '</div>';

				if(! empty($fields['events_callout_title'])){
					echo '<div class="col-lg-4">
							<div class="upcoming-events">
								<h3>'.$fields['events_callout_title'].'</h3>
								'.apply_filters('the_content', $fields['events_callout_text']).'
								'.pk_display_pk_button($fields['events_callout_button'], 'btn btn-primary btn-thin', false).'
							</div>
						</div>';
				}
			?>
		</div>
	</div>
	<script id="event-tempate" type="text/template">
		<?php 
			$event = new stdClass();
			$event->event_id = '<%event_id%>';
			$event->url = '<%url%>';
			$event->start_date = '<%start_date%>';
			$event->title = '<%title%>';
			$event->city = '<%city%>';
			$event->state = '<%state%>';
			$event->no_img = '<%no_img%>';

			pk_display_event_card($event);
		?>
	</script>
	<script>
		jQuery(document).ready(function($){

			var eventTemplate = $('#event-tempate').html();

			// Before we can load our events we need the user location. We are setting this in our dev.js file so it should be available after the user visits the page the first time
			if(userLocation){
				getEventsNearUser(userLocation);
			}else{
				$.getJSON('http://www.geoplugin.net/json.gp?jsoncallback=?', function(data) {
					if(data && data.geoplugin_city){
						getEventsNearUser(data);
					}
				},'json');
			}

			function getEventsNearUser(location){
				$('.user-city').val(location.geoplugin_city);

				var search = {};
				search.city = location.geoplugin_city,
				search.state = location.geoplugin_region,
				search.lat = location.geoplugin_latitude;
				search.lng = location.geoplugin_longitude;
				search.radius = 200;

				// Search for results
				$.post( '/api/events/nearest', search, function( data ) {
					if(data){
						if(data.error){
							console.log(data.error);
						}else{
							console.log(data);

							var newEventsHTML = '';

							// Build our new item html so we can spit out the entire string at once
							for(var d = 0; d < data.length; d++){

								newEventsHTML = PKTemplateEngine(eventTemplate, {
												event_id: data[d].event_id,
												url: data[d].url?data[d].url:'<?php echo pk_img_path().'NoPhotoIcon.svg'; ?>',
												start_date: moment(data[d].start_date).format('ddd, MMM D, YYYY - h:mma'), // D, F j, Y g:ia in PHP
												title: data[d].title,
												city: data[d].city,
												state: data[d].state,
												no_img: data[d].url?'':'no-image'
								});

								$('#event-'+(d+1)).html(newEventsHTML);
							}

						}
					}
				}, "json");
			}

			// HTML5 Geolocation, requires user accepting permissions
			// if (navigator.geolocation) {
			// 	navigator.geolocation.getCurrentPosition(showPosition);
			// }

			// function showPosition(position) {
			// 	console.log('position');
			// 	console.log(position);
			// 	// x.innerHTML = "Latitude: " + position.coords.latitude +
			// 	// "<br>Longitude: " + position.coords.longitude;
			// }

		}); 
	</script>

</section>