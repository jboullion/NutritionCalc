<?php 
	global $wpdb;

	$fields = pk_get('fields');
	$options = pk_get('options');

	// TODO: Setup all the filters to work with $_GET values

	$MarketItem = new MarketItem(0, $wpdb);

	$market_types = $MarketItem->get_types();
	$market_subtypes = $MarketItem->get_subtypes();
	$listing_types = $MarketItem->get_listing_types();
?>
<section class="no-print gray-back" id="marketplace-menu" >
	<h2 class="txt-center">Marketplace</h2>
	<?php // if(is_user_logged_in()): ?>
		<a class="btn btn-primary btn-full" href="#">Create New Post</a>
	<?php // endif; ?>

	<hr />

	<label>Price Range:</label>
	<div class="col-field d-flex">
		<input type="number" name="min-price" id="min-price" placeholder="100" maxlength="9" />
		<span class="spacer">-</span>
		<input type="number" name="max-price" id="max-price" placeholder="10,000" maxlength="9" />
	</div>

	<label class="mb-2">Listing Type:</label>
	<div class="col-field" id="listings">
		<?php 
			if(! empty($listing_types)){
				foreach($listing_types as $type){
					echo '<input type="radio" value="'.$type->listing_id.'" name="listing" id="listing-'.$type->listing_id.'" class="listing awesomebox" /><label for="listing-'.$type->listing_id.'">'.$type->type.'</label>';
				}
			}
		?>
	</div>

	<label class="mb-2">Categories:</label>
	<div class="col-field" id="types">
		<?php 
			if(! empty($market_types)){
				foreach($market_types as $type){
					// if($type->parent) continue;
					echo '<input type="radio" value="'.$type->type_id.'" name="type" id="type-'.$type->type_id.'" class="type awesomebox" /><label for="type-'.$type->type_id.'">'.$type->type.'</label>';
				}
			}
		?>
	</div>
	
	<div id="subtypes">
		<label class="mb-2">Sub Categories:</label>
		<div class="col-field">
			<?php 
				if(! empty($market_subtypes)){
					foreach($market_subtypes as $type){
						if(empty($type->parent)) continue;
						echo '<input type="radio" value="'.$type->subtype_id.'" name="subtype" id="subtype-'.$type->subtype_id.'" class="subtype awesomebox" /><label class="parent-'.$type->parent.' awesome-label" for="subtype-'.$type->subtype_id.'">'.$type->type.'</label>';
					}
				}
			?>
		</div>
	</div>

</section>