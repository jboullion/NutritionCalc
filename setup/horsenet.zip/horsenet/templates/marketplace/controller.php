<?php 
	global $wp_query;

	// Check if we have an item in our query vars
	$item_id = $wp_query->query_vars['item'];
?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo pk_get('map_key'); ?>&libraries=places&callback=initMap" async defer></script>

<script id="item-tempate" type="text/template">
	<div class="col-md-12 col-lg-6 col-xl-4">
		<?php 
			$item = new stdClass();
			$item->item_id = '<%item_id%>';
			$item->url = '<%url%>';
			$item->price = '<%price%>';
			$item->title = '<%title%>';
			$item->city = '<%city%>';
			$item->state = '<%state%>';
			$item->no_img = '<%no_img%>';

			pk_display_item_card($item);
		?>
	</div>
</script>

<script id="single-tempate" type="text/template">
	<div data-id="<%item_id%>" class="row single-item">
		<div class="col-lg-6 <%no_gallery%>">
			<?php 
				$item = new stdClass();
				$item->images = '<%images%>';
				$item->total_images = '<%total_images%>';

				pk_display_gallery($item);
			?>
		</div>
		<div class="col-lg-6  <%no_gallery_content%>">
			<?php 
				$item = new stdClass();
				$item->item_id = '<%item_id%>';
				$item->user_id = '<%user_id%>';
				$item->price = '<%price%>';
				$item->title = '<%title%>';
				$item->city = '<%city%>';
				$item->state = '<%state%>';
				$item->first_name = '<%first_name%>';
				$item->last_name = '<%last_name%>';
				$item->user_img = '<%user_img%>';
				$item->created = '<%created%>';
				$item->desc = '<%desc%>';

				pk_display_item_content($item);
			?>
		</div>
	</div>
	<div id="related-items" class="row">
		<div class="col-12">
			<h2 class="txt-center">Related Marketplace Items</h2>
		</div>
	</div>
</script>

<script id="slide-tempate" type="text/template">
	<?php 
		$slide = new stdClass();
		$slide->url = '<%url%>';
		$slide->width = '<%width%>';
		$slide->height = '<%height%>';
		$slide->large_url = '<%large_url%>';

		pk_display_gallery_slide($slide);
	?>
</script>

<script>

var autocomplete, 
	map,
	marker = null,
	circle = null,
	addressSearch = document.getElementById('location'),
	searchArea = document.getElementById('search-area'),
	radius = document.getElementById('radius'),
	scrollToTarget = document.getElementById("marketplace-listing"),
	loadedItems = 0,
	queryMax = 0,
	relatedLoadedItems = 0,
	relatedQueryMax = 0,
	$city = jQuery('#city'),
	$state = jQuery('#state'),
	$radius = jQuery('#radius'),
	$updateLocation = jQuery('#update-location'),
	$locationModal = jQuery('#modal-location'),
	$sortBy = jQuery('#sort-by'),
	$msearch = jQuery('#msearch'),
	$min = jQuery('#min-price'),
	$max = jQuery('#max-price'),
	$types = jQuery('#types'),
	$typeInputs = jQuery('#types .type'),
	$subtypes = jQuery('#subtypes'),
	$listings = jQuery('#listings'),
	$numResults = jQuery('span.num-results'),
	$resultsRow = jQuery('#results-row'),
	$singleItem = $('#single-item'),
	singleItemID = <?php echo $item_id?$item_id:0; ?>,
	$loadingIcon = jQuery('#load-target'),
	$itemListing = jQuery('#item-listing'),
	$relatedItems = jQuery('#related-items'),
	itemTemplate = jQuery('#item-tempate').html(),
	singleTemplate = jQuery('#single-tempate').html(),
	slideTemplate = jQuery('#slide-tempate').html(),
	noImgUrl = '<?php echo pk_img_path().'NoPhotoIcon.svg'; ?>';


//Setup our address map in our Gravity form
function initMap() {
	jQuery(document).ready(function($){
		// Find out where this user is from so we can start our search here
		
		// Before we can load our map let's make sure we have our user location. We are saving this as a cookie, but if we don't have it we have to generate it
		if(userLocation){
			setupAutocompleteAndMap(userLocation);
		}else{
			$.getJSON('http://www.geoplugin.net/json.gp?jsoncallback=?', function(data) {
				if(data && data.geoplugin_city){
					setupAutocompleteAndMap(data);
				}
			});
		}
	});
}

// Setup our autocomplete functionality and build our map. This requires having the user location available 
function setupAutocompleteAndMap(location){

	// Setup our initial search location based on the location data we returned from the user
	searchArea.value = location.geoplugin_city+', '+location.geoplugin_regionCode+' • '+radius.value+' mi';
	addressSearch.value = location.geoplugin_city+', '+location.geoplugin_regionCode;

	$city.val(location.geoplugin_city);
	$state.val(location.geoplugin_regionCode);

	// Initial item load.
	loadItems();

	map = new google.maps.Map(document.getElementById('map'), {
		center: {lat: parseFloat(location.geoplugin_latitude), lng: parseFloat(location.geoplugin_longitude)}, 
		zoom: 5,
		fullscreenControl: false,
		mapTypeControl: false,
		disableDefaultUI: true,
		scrollwheel: false,
		draggable: false,
		panControl:false,
		zoomControl:false,
		scaleControl:false,
		streetViewControl:false,
		overviewMapControl:false,
		rotateControl:false,
	});

	updateMap(location.geoplugin_city, location.geoplugin_latitude, location.geoplugin_longitude);

	// We only want google to return cities instead of all addresses
	var options = {
		types: ['(cities)'],
		componentRestrictions: {country: 'us'}
	};

	autocomplete = new google.maps.places.Autocomplete(addressSearch, options);

	//Limit the information we pull from the places API to increase speed and decrease potential costs
	autocomplete.setFields(['geometry', 'name', 'address_components']); //, 'icon', 'address_components', 

	//Update our map when our address location changes
	autocomplete.addListener('place_changed', function(){

		// Get the place details from the autocomplete object.
		var place = this.getPlace();
		// console.log(place);

		if (! place) {
			return;
		}

		if (! place.geometry) {
			console.log("Returned place contains no geometry");
			return;
		}

		var city = place.address_components.find(item => item.types.includes('locality'));
		var stateAbbr = place.address_components.find(item => item.types.includes('administrative_area_level_1'));

		$city.val(city.long_name);
		$state.val(stateAbbr.short_name);

		addressSearch.value = city.long_name+', '+stateAbbr.short_name;

		updateMap(place.name, place.geometry.location.lat(), place.geometry.location.lng());

	});
}

//Disable Address Search Autocomplete
addressSearch.onfocus = function(){
	//Gforms is doing some kind of funky dance with autocomplete so we need to delay this a bit in order to ensure our address search does not autocomplete
	addressSearch.autocomplete = 'nope';
};

jQuery(document).ready(function($){

	// We are using the jQuery waypoints plugin to detect when we need to page load
	var onChange = [$msearch,$sortBy,$min,$max,$types,$subtypes,$listings], // ,$city,$state,$radius
		radioButtons = [$types,$subtypes,$listings],
		onChangeElements = $.map(onChange, function(el){return el.get()});
		radioButtonElements = $.map(radioButtons, function(el){return el.get()});


	// debounce our loadItems function
	var dLoadItems = debounce(function() {
		loadItems();
	}, 300);

	// debounce our loadRelatedItems function
	var dLoadRelatedItems = debounce(function() {
		loadRelatedItems();
	}, 300);


	// Clear the item list and load a new search
	function clearSearch(push){
		singleItemID = 0;
		loadedItems = 0;
		queryMax = 0;
		$itemListing.html('');

		if(push){
			history.pushState({page: 1}, 'Marketplace', "/marketplace/");
		}

		dLoadItems();
	}


	// Detect scrolling to the bottom of the document
	window.onscroll = function(ev) {
		if ((window.innerHeight + window.pageYOffset) >= document.body.offsetHeight) {
			//alert("you're at the bottom of the page");
			if(! singleItemID) {
				// Load Marketplace Items
				dLoadItems();
			}else{
				// Load Related Items
				dLoadRelatedItems();
			}
		}
	};

	// TODO: We might need to setup some kind of GET variable option which will allow users to setup the same search as other users
	// TODO: That is to say, when selecting a filter should we do a pushstate() of the '?'+parseQueryVars(search)?
	// Listen for user input to the search funcions
	$(onChangeElements).on('change', function(){
		clearSearch(true);
	});

	// Update the search area from the location modal
	$updateLocation.click(function(e){
		clearSearch(true);

		//Update our displayed search value
		searchArea.value = $city.val()+', '+$state.val()+' • '+$radius.val()+' mi';

		$locationModal.modal('hide');
	})

	// Allow the user to unselect a radio button
	$(radioButtonElements).on('click', 'input', function(e){
		if($(this).hasClass('checked')){
			// If this was already marked as checked then we need to uncheck it
			$(this).prop('checked', false);
		}else{
			// If the user is clicking on an element that hasn't been checked remove all other class checks
			$(this).parents('.col-field').find('input').removeClass('checked');
		}

		// Regardless of what happens we want to toggle our 'checked' class
		$(this).toggleClass('checked');

		// Trigger change so we know to reload the search criteria
		$(this).trigger('change');

	});


	// Listen for user input to the search funcions
	$radius.on('change', function(){
		var currentRadius = parseInt($radius.val());
		var zoomLevel = getZoomLevel(currentRadius);

		displayCircle(currentRadius);

		map.setZoom(zoomLevel);

	});

	// Hide / Show the subtypes based on what type is selected
	$typeInputs.change(function(e){
		singleItemID = 0;

		$subtypes.hide().find('.awesome-label').hide();
		if($(this).prop('checked')){
			var parentID = $(this).val();
			var $childTypes = $subtypes.find('.parent-'+parentID);
			if($childTypes.length){
				$subtypes.show();
				$childTypes.show();
			}
		}
	});

	// Listen for any clicks on the card items so we can load them correctly
	$itemListing.on('click', '.card.item', function(e){
		e.preventDefault();
		e.stopPropagation();

		clickSingleItem($(this));

		return false;
	});

	// TODO: We need to setup loading of related items while on the single item page
	// Listen for any clicks on the card items so we can load them correctly
	$singleItem.on('click', '.card.item', function(e){
		e.preventDefault();
		e.stopPropagation();

		clickSingleItem($(this));

		return false;
	});

	// Listen for the 'popstate' event which will let us know if we are using the back button to manipulate the history api and NOT when going back to a different page
	$(window).on('popstate', function(event) {
		loadedItems = 0;

		//Sometimes we have a trailing "/" in our url, if that is the 
		if (window.location.pathname.charAt(window.location.pathname.length - 1) == '/') {
			var whatUrl = window.location.pathname.substr(0, window.location.pathname.length - 1);
		}else{
			var whatUrl = window.location.pathname;
		}

		// If we are popping back to the marketplace we need to set the correct single item ID
		var checkID = whatUrl.split("/").pop();

		if(! checkID || isNaN(checkID)){
			clearSearch();
		}else{
			singleItemID = checkID;
			displayItem(singleItemID);
		}

	});

});

// Show a single item instead of loading multiple items
function displayItem(itemID){
	$resultsRow.hide();
	$itemListing.hide();
	$singleItem .show();

	$loadingIcon.show();

	jQuery.post( '/api/marketplace/item', {item_id:itemID}, function( item ) {
		if(item){
			if(item.error){
				console.log(item.error);
			}else{
				// console.log(item);

				var newSlideHTML = '';
				var numImages = 0;
				if(item.images){
					numImages = item.images.length;
					// // Build our new slide html so we can spit out the entire string at once
					for(var d = 0; d < item.images.length; d++){

						newSlideHTML += PKTemplateEngine(slideTemplate, {
									url: item.images[d].url?item.images[d].url:'',
									large_url: item.images[d].large_url?item.images[d].large_url:'',
									width: item.images[d].width?item.images[d].width:0,
									height: item.images[d].height?item.images[d].height:'',
									title: item.images[d].title?item.images[d].title:'',
									desc: item.images[d].desc?item.images[d].desc:'',
						});

					}
				}

				// Build our new item html so we can spit out the entire string at once
				var newSingleHTML = PKTemplateEngine(singleTemplate, {
								item_id: item.item_id?item.item_id:0,
								user_id: item.user_id?item.user_id:0,
								price: item.price?parseFloat(item.price).pkFormatMoney(0, '.', ','):'',
								title: item.title?item.title:'',
								city: item.city?item.city:'',
								state: item.state?item.state:'',
								first_name: item.first_name?item.first_name:'',
								last_name: item.last_name?item.last_name.charAt(0):'',
								user_img: item.user_img?item.user_img:'',
								created: item.created?item.created:'',
								desc: item.desc?item.desc:'',
								images: newSlideHTML?newSlideHTML:'',
								total_images: numImages?numImages:0,
								no_gallery: numImages?'':'d-none',
								no_gallery_content: numImages?'':'offset-lg-3',
				});

				// Update our document with the new information
				$singleItem.html(newSingleHTML);
				$loadingIcon.hide();
				
				// Reset our related items loading
				relatedLoadedItems = 0;
				relatedQueryMax = 0;

				// Scroll to the top of the item screen. Has a better feel than just jumbling things around
				scrollToTarget.scrollIntoView();

				initItemGallery();
			}
		}
	}, "json");
	
}

// Initialize our item gallery after inserting it into the dom
// This also initializes the PhotoSwipe lightbox gallery
function initItemGallery(){
	var $viewGallery = jQuery('#view-gallery'),
		$galleryCount = jQuery('.gallery-count .current');
		//$galleryTarget = jQuery('.owl-item.active');

	jQuery('#gallery-carousel').owlCarousel({
		loop: false,
		autoHeight: false,
		lazyLoad: false,
		margin: 10,
		responsiveClass: false,
		slideBy: 1,
		nav: true,
		navText: ['<i class="fal fa-angle-left"></i>','<i class="fal fa-angle-right"></i>'],
		dots: false,
		itemElement: 'figure',
		responsive:{
			0:{
				items:1
			}
		}
	}).on('changed.owl.carousel', function(e) {
		$galleryCount.html(e.item.index+1);
	});

	// execute above function
	initPhotoSwipeFromDOM('#gallery-carousel');

	// Allow the user to open the photoswipe gallery by clicking on the "view gallery" button
	$viewGallery.click(function(e){
		jQuery('.owl-item.active').trigger('click');
	});
}

// Show a single item
function clickSingleItem($this){
	var itemID = $this.data('id');
	var itemTitle = $this.data('title');

	if(itemID && ! isNaN(itemID)) {
		singleItemID = itemID;

		history.pushState({page: 1}, itemTitle, "/marketplace/item/"+itemID);
		displayItem(itemID);
	}
}

// Update our location map on initial load and after new cities are selected
function updateMap(title, lat, lng){
	// Clear out the old marker.
	if(marker){
		marker.setMap(null);
	}

	var currentRadius = parseInt($radius.val());

	// Create a marker for each place.
	marker = new google.maps.Marker({
		map: map,
		//icon: icon,
		title: title,
		position: {lat: parseFloat(lat), lng: parseFloat(lng)}
	});

	displayCircle(currentRadius);

	//Show our place on the map
	map.setCenter({lat: parseFloat(lat), lng: parseFloat(lng)});

	zoomLevel = getZoomLevel(currentRadius);

	map.setZoom(zoomLevel);

}

// Display a circle on our location map based on the current marker position and the currently selected radius
function displayCircle(currentRadius){
	if(circle){
		circle.setMap(null);
	}

	if(currentRadius > 0){
		// Add circle overlay and bind to marker
		circle = new google.maps.Circle({
			map: map,
			radius: currentRadius * 1609.34,    // miles to metres
			fillColor: '#FFFFFF',
			strokeColor: '#FFFFFF',
		});

		circle.bindTo('center', marker, 'position');
	}
}

// Get the zoom level based on the currently selected radius. These seemed to work better than trying to set the bounds by the circle diameter
function getZoomLevel(currentRadius){
	var zoomLevel = 8;
	if(currentRadius < 50){
		zoomLevel = 8;
	}else if(currentRadius < 100){
		zoomLevel = 7;
	}else if(currentRadius < 200){
		zoomLevel = 6;
	}else{
		zoomLevel = 5;
	}

	return zoomLevel;
}


/**
 * Load related items based on an itemID
 */
function loadRelatedItems(){

	// If we already loaded everything in this query no need to load anymore
	if(relatedLoadedItems > 0 && relatedLoadedItems >= relatedQueryMax){
		return;
	}

	// Show our loading icon
	$loadingIcon.show();

	var search = {};
	search.item_id = singleItemID;
	search.offset = relatedLoadedItems;

	// Search for results
	jQuery.post( '/api/marketplace/related', search, function( data ) {
		if(data){
			if(data.error){
				console.log(data.error);
			}else{

				// console.log(data);
				
				relatedLoadedItems += data.items.length;

				var newItemsHTML = '';

				// Build our new item html so we can spit out the entire string at once
				for(var d = 0; d < data.items.length; d++){
					
					// console.log(data.items[d]);
					newItemsHTML += PKTemplateEngine(itemTemplate, {
									item_id: data.items[d].item_id?data.items[d].item_id:0,
									url: data.items[d].url?data.items[d].url:noImgUrl,
									price: data.items[d].price?parseFloat(data.items[d].price).pkFormatMoney(0, '.', ','):'',
									title: data.items[d].title?data.items[d].title:'',
									city: data.items[d].city?data.items[d].city:'',
									state: data.items[d].state?data.items[d].state:'',
									no_img: data.items[d].url?'':'no-image'
					});
				}

				// Update our document with the new information
				relatedQueryMax = data.max;
				jQuery('#related-items').append(newItemsHTML);
				$loadingIcon.hide();

			}
		}
	}, "json");
}


/**
 * Load items based on the search criteria available
 */
function loadItems(){

	if(singleItemID && ! isNaN(singleItemID)) {
		displayItem(singleItemID);
		return;
	}

	// TODO: We might need to add a history push state when a user is searching WHILE looking at a single item
	// history.pushState({page: 1}, 'Marketplace, "/");

	// If we already loaded everything in this query no need to load anymore
	if(loadedItems > 0 && loadedItems >= queryMax){
		return;
	}

	// Build our search parameters
	var search = {};
	search.search = $msearch.val();
	search.city = $city.val();
	search.state = $state.val();
	search.radius = $radius.val();
	search.min = $min.val();
	search.max = $max.val();
	search.type = $types.find("input[name='type']:checked").val();
	search.subtype = $subtypes.find("input[name='subtype']:checked").val();
	search.listing = $listings.find("input[name='listing']:checked").val();
	search.sortBy = $sortBy.val(),
	search.offset = loadedItems;

	// console.log(search);

	// Show our loading icon
	$loadingIcon.show();

	// Search for results
	// TODO: Need to test this on IE because sending parameters with a single variable MIGHT not work on IE
	jQuery.post( '/api/marketplace/search', search, function( data ) {
		if(data){
			if(data.error){
				console.log(data.error);
			}else{

				// console.log(data);
				loadedItems += data.items.length;

				var newItemsHTML = '';

				// Build our new item html so we can spit out the entire string at once
				for(var d = 0; d < data.items.length; d++){

					newItemsHTML += PKTemplateEngine(itemTemplate, {
									item_id: data.items[d].item_id,
									url: data.items[d].url?data.items[d].url:noImgUrl,
									price: data.items[d].price?parseFloat(data.items[d].price).pkFormatMoney(0, '.', ','):'',
									title: data.items[d].title?data.items[d].title:'',
									city: data.items[d].city?data.items[d].city:'',
									state: data.items[d].state?data.items[d].state:'',
									no_img: data.items[d].url?'':'no-image'
					});
				}

				// Update our document with the new information
				queryMax = data.max;
				$singleItem .hide();
				singleItemID = 0;
				$itemListing.show();
				$resultsRow.css('display', 'flex');
				$numResults.html(data.max+' Items');
				$itemListing.append(newItemsHTML);
				$loadingIcon.hide();

			}
		}
	}, "json");
}
</script>