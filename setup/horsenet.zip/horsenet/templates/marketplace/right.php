<?php 
	$fields = pk_get('fields');
	$options = pk_get('options');

	// global $wp_query;

	// if(! empty($_GET['item']) && is_numeric($_GET['item'])){
	// 	$MarketItem = new MarketItem($_GET['item'], $wpdb);

	// 	$item = $MarketItem->get_info();

	// 	$latest_items = $MarketItem->get_latest_items(3);

	// }

	// Check if we have an item in our query vars
	// $item_id = $wp_query->query_vars['item'];
?>
<section class="wrapper no-print white-back" id="marketplace-listing" >
	<div class="container">
		<div class="row">
			<div class="col-md-8 search">
				<div class="input-group">
					<input type="text" class="no-focus" id="msearch" maxlength="30" placeholder="Search the Marketplace for...">
					<div class="input-group-append">
						<button type="submit" class="btn"><i class="fas fa-search"></i></button>
					</div>
				</div>
			</div>
			<div class="col-md-4 location">

				<div class="input-group" data-toggle="modal" data-target="#modal-location">
					<!-- Madison, WI &bull; 60 mi -->
					<input type="text" class="no-focus" id="search-area" value="" readonly />
					<div class="input-group-append">
						<i class="btn fas fa-map-marker-alt"></i>
					</div>
				</div>

			</div>
		</div>

		<div id="results-row" class="row">
			<div class="col-lg-6">
				<span>Showing <span class="txt-brown num-results"><?php echo $search_items['max']; ?> Items</span></span>
			</div>
			<div class="col-lg-6">
				<div class="gray-select alignright pk-select">
					<span>Sort By: </span>
					<select id="sort-by">
						<option value="date-desc">Newest</option>
						<option value="date-asc">Oldest</option>
						<option value="name-asc">A - Z</option>
						<option value="name-desc">Z - A</option>
						<option value="price-asc">Lowest Price</option>
						<option value="price-desc">Highest Price</option>
					</select>
				</div>
			</div>
		</div>
		
		<div id="single-item"></div>

		<div id="item-listing" class="row"></div>

		<div id="load-target">
			<?php include get_stylesheet_directory().'/images/loading.svg'; ?>
		</div>
	</div>
</section>
