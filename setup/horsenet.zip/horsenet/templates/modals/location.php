<div id="modal-location" class="modal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<h3 class="modal-title">Change Location</h3>
			<button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">
				<i class="fas fa-times"></i>
			</button>
		</div>
		<div class="modal-body">
			<div class="map-filters">

				<div class="form-group">
					<label>Location</label>
					<div class="input-group">
						
						<input type="text" name="location" id="location" value="" />
						<div class="input-group-append">
							<i class="btn fas fa-map-marker-alt"></i>
						</div>
					</div>
				</div>

				<div class="spacer"></div>

				<div class="form-group">
					<label>Radius</label>
					<div class="input-group">
						
						<div class="pk-select">
							<select id="radius">
								<option value="30" selected="selected">30 miles</option>
								<option value="50">50 miles</option>
								<option value="100">100 miles</option>
								<option value="200">200 miles</option>
								<option value="0">Unlimited</option>
							</select>
						</div>
					</div>
				</div>

			</div>

			<div id="map"></div>
		</div>
		<div class="modal-footer">
			<input type="hidden" name="city" id="city" value="" />
			<input type="hidden" name="state" id="state" value="" />
			<button type="button" class="btn btn-primary btn-full" id="update-location">Update Location</button>
		</div>
		</div>
	</div>
</div>