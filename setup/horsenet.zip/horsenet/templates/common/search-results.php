<?php 
	global $wp_query;

	$options = pk_get('options');
?>
<section id="search-results" class="wrapper white-back" >
	<div class="container">
		<div class="row">
			<div class="col-12 content">
				<?php 
					if(have_posts() && ! empty($_GET['s'])): 
						echo '<h3>'.$wp_query->post_count.' Results for "'.$_GET['s'].'"</h3>';

						echo get_search_form();

						while(have_posts()): 
							the_post(); 

							$ptype = pk_get_post_type();

							echo '<div class="search-result">
									<h4><a href="'.get_the_permalink().'">'.$post->post_title.'</a></h4>

									<div class="meta">
										'.$ptype.'
									</div>
								</div>';

						endwhile; 
						
						echo '<div class="pagination">';
					
						echo paginate_links( array(
							'format' => 'page/%#%',
							'current' => max( 1, get_query_var('paged') ),
							'total' => $wp_query->max_num_pages,
							'prev_text' => __('&lsaquo;'),
							'next_text' => __('&rsaquo;')
						) );
						
						echo '</div>';

					else:

						echo '<h2>No Results Found.</h2>';
					endif; 
				?>
			</div>
		</div>
	</div>
</section>