<?php 
	$options = pk_get('options');
?>
<section id="header">
	<div id="logo">
		<a href="/" >
			<img class="" src="<?php echo $options['logo']['url']; ?>" alt="<?php bloginfo('name'); ?>" />
		</a>
	</div>

	<nav id="main-navigation" role="navigation">
		<?php 
			wp_nav_menu(
				array(
					'container'=> false, 
					'depth'=>2, 
					'menu'=>2
				)
			); 
		?>
	</nav>

	<div id="search">
		<?php echo get_search_form(); ?>
	</div>

	<div id="account">
		<a href="#" class="btn btn-secondary">Login</a>
		<a href="#" class="btn btn-primary">Sign Up</a>
	</div>

	<button type="button"  class="collapsed" id="main-navigation-toggle">
		<span class="sr-only">Toggle Navigation</span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
	</button>
</section>