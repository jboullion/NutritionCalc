<?php 
	$fields = pk_get('fields');
	$options = pk_get('options');


	//https://spigotdesign.com/tribe-events-conditionals/
	if ( tribe_is_past() || tribe_is_month() || tribe_is_upcoming() && !is_tax()) {
		$title = 'Events';
		//$featured_image = $options['default_featured_image']['url'];
	}else if(is_tax( 'tribe_events_cat' )){
		$tax_object = get_queried_object();
		$title = 'Events: '.$tax_object->name;
	}else if(is_404()){
		$title = 'Error 404';
		//$featured_image = $options['default_featured_image']['url'];
	}else if(is_search()){
		$title = 'Search Results';
		//$featured_image = $options['default_featured_image']['url'];
	}else{
		$title = get_the_title();
		$featured_image = pk_get_featured_image();
		if(empty($featured_image)){
			$featured_image = $options['default_featured_image']['url'];
		}
	}
?>
<section class="wrapper no-print setup-background lazy" id="featured" data-src="<?php echo $featured_image; ?>">
	<div class="overlay diagonal-shadow">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<h1><?php echo $title; ?></h1>
				</div>
			</div>
		</div>
	</div>
</section>