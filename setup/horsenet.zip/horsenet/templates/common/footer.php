<?php 
	$options = pk_get('options');
?>
<footer class="wrapper no-print" id="footer">
	<div class="container">

		<div class="row">
			<div class="col-12 col-lg-8 offset-lg-2 foot-logo">
				<a href="/">
					<img src="<?php echo $options['footer_logo']['url']; ?>" 
						loading="lazy" 
						width="<?php echo $options['footer_logo']['width']; ?>" 
						height="<?php echo $options['footer_logo']['height']; ?>" 
						class="lazy" alt="<?php bloginfo('name'); ?>"
						alt="<?php bloginfo('name'); ?>" />
				</a>
			</div>
		</div>

		<div class="row">
			<div class="col-12">
				<nav class="navbar" id="main-navigation" role="navigation">
						<?php 
							wp_nav_menu(
								array(
									'container' => false,
									'depth'=>2, 
									'menu'=>3,
								)
							); 
						?>
					</nav>
			</div>
		</div>

		<div class="row">
			<div class="col-12 copyright">
				&copy; <?php echo date('Y').' '.get_bloginfo('name'); ?> All rights reserved.
			</div>
		</div>

	</div>
</footer>