<?php 
	get_header(); 
?>
<div id="search-page" class="page">
	<?php get_template_part('templates/common/featured'); ?>

	<?php get_template_part('templates/common/search','results'); ?>
</div>
<?php 
	get_footer();