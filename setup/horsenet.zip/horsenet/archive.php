<?php 
	get_header(); 
?>
<div id="contact-page" class="page">
	<?php get_template_part('templates/common/loop'); ?>
</div>
<?php 
	get_footer();
