<?php 

add_action( 'init', 'pk_set_vars' );
function pk_set_vars() {
	$options = get_fields('options');
	pk_set('options',$options);
	
	// format a few address variables
	pk_set('single_line_street_address', str_replace('<br />', ' ', pk_get('street_address')));
	pk_set('single_line_full_address', pk_get('single_line_street_address').', '.pk_get('city').', '.pk_get('state').' '.pk_get('zip'));

	// format a few phone variables (and set a site wide phone format for consistency)
	pk_set('phone_formats', array('format-7'=>'$1-$2', 'format-10'=>"($1) $2-$3", 'format-11'=>"$1 ($2) $3-$4"));
	pk_set('phone_formatted', pk_format_phone(pk_get('phone'), '', pk_get('phone_formats')));
	pk_set('fax_formatted', pk_format_phone(pk_get('fax'), '', pk_get('phone_formats')));

	pk_set('map_key', 'AIzaSyDFxtU4EIwl1SVaYhxIZ1Pew14F1AymgfA'); //AIzaSyDKK63ADAJUez9w8JmRXSsBCUikNXVU2KQ

	// enable customer login logo
	pk_set('pk-login-logo', 'images/logo.png');

	// https://www.geoplugin.com/quickstart
	// https://www.geoplugin.com/webservices/php#php_class
	// NOTE: This is an attempt at getting the user location from our server however this doesn't seem to be as accurate as with JS. This might work better on live than on local development, but I have left this functionality entirely in the JS for now
	// $user_location = file_get_contents_curl('http://www.geoplugin.net/php.gp?ip='.$_SERVER['REMOTE_ADDR']);
	// pk_print(unserialize($user_location));

	// Setup a rewrite rule for item get variables 
	add_rewrite_rule(
		'marketplace/item/(.+?)/?$',
		'index.php?pagename=marketplace&item=$matches[1]&test=1',
		'top'
	);
}

add_filter( 'query_vars', 'pk_add_query_vars' ); 
function pk_add_query_vars( $query_vars ){
    $query_vars[] = "item";
    return $query_vars;
}



/**
 * Remove the 'defer' attribute from the jquery-core so we make sure it is loaded for the rest of the site to use as needed
 */
add_filter('script_loader_tag', 'pk_async_attribute', 10, 2);
function pk_async_attribute($tag, $handle) {
	if ( 'jquery-core' !== $handle )
		return $tag;
	return str_replace( 'defer', '', $tag );
}

// front end scripts/css
add_action('wp_enqueue_scripts', 'pk_theme_enqueue_scripts', 9999);
function pk_theme_enqueue_scripts() {

	// jQuery
	if ( is_admin() || is_customize_preview() ) {
		// echo 'We are in the WP Admin or in the WP Customizer';
		return;
	} else {
		// Deregister WP core jQuery, see https://github.com/Remzi1993/wp-jquery-manager/issues/2 and https://github.com/WordPress/WordPress/blob/91da29d9afaa664eb84e1261ebb916b18a362aa9/wp-includes/script-loader.php#L226
		wp_deregister_script( 'jquery' ); // the jquery handle is just an alias to load jquery-core with jquery-migrate
		// Deregister WP jQuery
		wp_deregister_script( 'jquery-core' );
		// Deregister WP jQuery Migrate
		wp_deregister_script( 'jquery-migrate' );

		// Register jQuery in the head
		wp_register_script( 'jquery-core', 'https://code.jquery.com/jquery-3.3.1.min.js', array(), null, false );

		/**
		 * Register jquery using jquery-core as a dependency, so other scripts could use the jquery handle
		 * see https://wordpress.stackexchange.com/questions/283828/wp-register-script-multiple-identifiers
		 * We first register the script and afther that we enqueue it, see why:
		 * https://wordpress.stackexchange.com/questions/82490/when-should-i-use-wp-register-script-with-wp-enqueue-script-vs-just-wp-enque
		 * https://stackoverflow.com/questions/39653993/what-is-diffrence-between-wp-enqueue-script-and-wp-register-script
		 */
		wp_register_script( 'jquery', false, array( 'jquery-core' ), null, false );
		wp_enqueue_script( 'jquery' );
	}

	if(ENVIRONMENT != 'dev') {
		wp_enqueue_style('live', get_stylesheet_directory_uri() . '/styles/live.css', array(), filemtime(get_stylesheet_directory().'/styles/live.css'));
		wp_enqueue_script('jquery.site', get_stylesheet_directory_uri() . '/js/live.js', 'jQuery', filemtime(get_stylesheet_directory().'/js/live.js'), true);
	} else {
		wp_enqueue_style('dev', get_stylesheet_directory_uri().'/styles/dev.css', array(), time());
		wp_enqueue_script('jquery.site', get_stylesheet_directory_uri().'/js/dev.js', 'jQuery', time(), true);
	}

}

//Change "posts" name to "Blog Posts"
add_filter('pk_change_post_label','pk_return_post_label');
function pk_return_post_label(){
	return 'Blog Post';
}

// filter to disable/enable block editor on a specific basis, full post object is passed with post type
add_filter('use_block_editor_for_post', 'pk_use_block_editor_for_post', 9999, 2);
function pk_use_block_editor_for_post($use_block_editor, $post) {
	return false;
}