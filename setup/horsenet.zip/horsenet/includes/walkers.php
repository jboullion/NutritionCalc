<?php 

// bootstrap nav walker
class Bootstrap_Dropdown_Walker_Texas_Ranger extends Walker_Nav_Menu {
	public function start_lvl(&$output, $depth = 0, $args = array()) {
		$indent = str_repeat("\t", $depth);
		$output.= "\n$indent".'<ul role="menu" class="dropdown-menu">'."\n";
	}
	public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
		if($args->has_children) {
			$item->classes[] = 'dropdown';
		}
		parent::start_el($output, $item, $depth, $args);
	}
	public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
		if(is_object($args[0])) {
			$args[0]->has_children = !empty($children_elements[$element->{$this->db_fields['id']}]);
		}
		parent::display_element($element, $children_elements, $max_depth, $depth, $args, $output);
	}
}