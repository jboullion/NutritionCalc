<?php 


// update email from address
// add_filter('wp_mail_from', function () { return ''; });
// add_filter('wp_mail_from_name', function() { return get_bloginfo('name'); });

// wp engine cache functions
/*add_action('init','pk_wpengine_clears');
function pk_wpengine_clears(){
	if(class_exists('WpeCommon') && function_exists('pk_wpe_add_page_relationship')) { 
		$home_id = get_option('page_on_front');
		$home_id = $home_id ? $home_id : 1;
		pk_wpe_add_page_relationship(array('post_type'=>'', 'pages_to_clear'=>array(1,2,3)));
	}
}*/