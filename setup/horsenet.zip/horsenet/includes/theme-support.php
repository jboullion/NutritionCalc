<?php
	//Add Featured Image Support
	add_theme_support( 'post-thumbnails' ); 
	
	// enable html5shiv
	add_theme_support('pk-html5shiv');

	// enable selectivizr
	add_theme_support('pk-selectivizr');
	
	// enable responsive
	add_theme_support('pk-responsive');
	