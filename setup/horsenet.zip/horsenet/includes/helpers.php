<?php 

/**
 * Get the link to a specific event
 * 
 * @param Object $event The event object
 * 
 * @return string A link to this event's page
 */
function get_event_link($event){
	return '/event/'.$event->event_id.'/';
}

/**
 * Get the link to a specific member
 * 
 * @param Object $member The member object
 * 
 * @return string A link to this member's page
 */
function get_member_link($member){
	return '/member/'.$member->user_id.'/';
}

/**
 * Get the link to a specific item
 * 
 * @param Object $item The item object
 * 
 * @return string A link to this item's page
 */
function get_item_link($item){
	// return '/marketplace/item/'.$item->item_id;
	return '/marketplace/item/'.$item->item_id;
}

/**
 * Since we can't be guaranteed to have file_get_contents we are setting up a replacement function that should always work
 * 
 * @param string $url The url to get the contents of
 * 
 * @return mixed The result of the curl request
 */
function file_get_contents_curl($url) {
	$ch = curl_init();

	curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       

	$data = curl_exec($ch);
	curl_close($ch);

	return $data;
}