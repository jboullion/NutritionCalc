<?php 

	/**
	 * Display an item card!
	 * 
	 * Note: This is also called when building JS template so every variable should be able to be switched out with a replacement string like <%item_id%>
	 * 
	 * @param Object $item This should be an item object in the same structure as it is returned from the MarketItem Class
	 */
	function pk_display_item_card($item){

		echo '<a href="'.get_item_link($item).'" 
			data-id="'.$item->item_id.'" 
			data-title="'.$item->title.'"
			class="card item '.($item->url?'':'no-image').' '.($item->no_img?$item->no_img:'').'">';

		pk_display_card_img($item->url, false);

		echo '		<div class="card-body">
						<span class="price">$'.(is_numeric($item->price)?number_format($item->price):$item->price).'</span>
						<h3 class="card-title">'.$item->title.'</h3>
						<span class="location"><i class="fas fa-map-marker-alt"></i> '.$item->city.', '.$item->state.'</span>
					</div>
				</a>';
	}


	/**
	 * Display a member card!
	 * 
	 * @param Object $member This should be a member object in the same structure as it is returned from the Member Class
	 */
	function pk_display_member_card($member){

		echo '<a href="'.get_event_link($member).'" class="card member '.($member->url?'':'no-image').' '.($member->no_img?$member->no_img:'').'">';

		pk_display_card_img($member->url);

		echo '		<div class="card-body">
						<h4 class="card-title">'.$member->first_name.' '.$member->last_name[0].'.</h4>
						<span class="location"><i class="fas fa-map-marker-alt"></i> '.$member->city.', '.$member->state.'</span>
						<span class="horse-count"><i class="fas fa-horse-head"></i> '.$member->horse_count.'</span>
					</div>
				</a>';
	}


	/**
	 * Display an event card!
	 * 
	 * @param Object $event This should be an event object in the same structure as it is returned from the Event Class
	 */
	function pk_display_event_card($event){

		echo '<a href="'.get_event_link($event).'" class="card event '.($event->url?'':'no-image').' '.($event->no_img?$event->no_img:'').'">';

		pk_display_card_img($event->url);

		echo '		<div class="card-body">
						<span class="price">'.(strtotime($event->start_date)?date('D, F j, Y g:ia', strtotime($event->start_date)):$event->start_date).'</span>
						<h3 class="card-title">'.$event->title.'</h3>
						<span class="location"><i class="fas fa-map-marker-alt"></i> '.$event->city.', '.$event->state.'</span>
					</div>
				</a>';
	}


	/**
	 * Most of our cards are going to have the same card-img element
	 * 
	 * @param string $url The url of the card image you want to use
	 */
	function pk_display_card_img($url, $lazy = false){
		if(empty($url)){
			$url = pk_img_path().'NoPhotoIcon.svg';
		}

		//Note: I tried to use lazy load here but it meant the images just off screen had no image showing
		if($lazy){
			echo '<div class="card-img setup-background lazy" data-src="'.$url.'"></div>';
		}else{
			echo '<div class="card-img setup-background" style="background-image: url( '.$url.' );"></div>';
		}
	}


	/**
	 * Display a gallery
	 * 
	 * Note: This is also called when building JS template so every variable should be able to be switched out with a replacement string like <%item_id%>
	 * 
	 * @param Object $item This should be an item object in the same structure as it is returned from the MarketItem Class
	 */
	function pk_display_gallery($item){
		if(! empty($item)){
			echo '<div class="gallery">
					<div id="gallery-carousel" class="owl-carousel" itemscope itemtype="http://schema.org/ImageGallery">';

			if(is_array($item->images)){
				foreach($item->images as $key => $img){
					pk_display_gallery_slide($img);
				}
			}else if(is_string($item->images)){
				echo $item->images;
			}

			echo '</div>
					<div class="gallery-info">
						<span class="gallery-count"><span class="current">1</span> of <span class="total">'.$item->total_images.'</span></span>
						
						<span id="view-gallery">
							View Gallery <i class="fas fa-images"></i>
						</span>
					</div>
				</div>';
		}
	}


	/**
	 * Display a single gallery slide
	 * 
	 * Note: This is also called when building JS template so every variable should be able to be switched out with a replacement string like <%item_id%>
	 * 
	 * @param Object $slide This should be slide object related to an image database
	 */
	function pk_display_gallery_slide($slide){
		// id="gallery-target"
		echo '<a href="'.$slide->url.'" itemprop="contentUrl" data-size="'.$slide->width.'x'.$slide->height.'">
				<div class="setup-background" style="background-image:url('.$slide->large_url.');"></div>
				<img itemprop="thumbnail" src="'.$slide->large_url.'" />
			</a>';
	}


	/**
	 * Display a single item's content
	 * 
	 * Note: This is also called when building JS template so every variable should be able to be switched out with a replacement string like <%item_id%>
	 * 
	 * @param Object $item This should be an item object in the same structure as it is returned from the MarketItem Class
	 */
	function pk_display_item_content($item){
		if(! empty($item)){
			echo '<div class="content">
					<span class="price">$'.$item->price.'</span>
					<h1>'.$item->title.'</h1>
					<div class="member-info">
						<img src="'.$item->user_img.'" alt="'.$item->first_name.' '.$item->last_name.'" title="'.$item->first_name.' '.$item->last_name.'" width="100" height="100" />
						<div class="member-name">
							<h4 class="card-title">'.$item->first_name.' '.$item->last_name.'.</h4>
							<span class="location"><i class="fas fa-map-marker-alt"></i> '.$item->city.', '.$item->state.'</span>
						</div>
						<div class="member-btn">
							<button type="button" class="btn btn-primary" data-id="'.$item->user_id.'">Message</button>
						</div>
					</div>
					<span class="item-posted"><strong>Posted:</strong> '.$item->created.'</span>
					'.$item->desc.'
				</div>';
		}
	}