<form role="search" method="get" class="search-form" action="<?php echo home_url(); ?>">
	<label class="sr-only">Search</label>
	<div class="input-group">
		<input type="search" id="search-field" class="search-field form-control" value="<?php echo get_search_query(); ?>" name="s" title="Search" required />
		<div class="input-group-append">
			<button type="submit" class="btn"><i class="far fa-search"></i></button>
		</div>
	</div>
</form>